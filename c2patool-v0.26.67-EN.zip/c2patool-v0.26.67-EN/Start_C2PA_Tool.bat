@echo off
chcp 65001 >nul
title TekNerds C2PA
cd /d "%~dp0"

rem Find Python: prefer the py launcher, otherwise python
set "PYEXE="
where py >nul 2>nul && set "PYEXE=py -3"
if "%PYEXE%"=="" ( where python >nul 2>nul && set "PYEXE=python" )

if "%PYEXE%"=="" (
  echo Python 3 was not found.
  echo Please install Python from https://www.python.org/downloads/
  echo ^(tick "Add python.exe to PATH" during setup^),
  echo OR use the EXE version ^(see build_exe.bat / README^).
  echo.
  pause
  goto :eof
)

echo Starting TekNerds C2PA ... (keep this window open)
echo If c2patool is missing it will be downloaded automatically on start.
echo Quit: power button in the app, or Ctrl+C here.
echo.
%PYEXE% "c2pa_signer.py"
pause
