@echo off
chcp 65001 >nul
title TekNerds C2PA - build EXE
cd /d "%~dp0"

echo ================================================================
echo   TekNerds C2PA  -  build standalone EXE (optional)
echo   Result:  dist\TekNerds C2PA.exe  (runs without Python)
echo ================================================================
echo.
echo Requires: Python 3 + internet (for PyInstaller).
echo c2patool.exe will be embedded.
echo.

if not exist "c2patool.exe" (
  echo c2patool.exe is missing - please run Setup.bat first.
  echo.
  pause
  goto :eof
)

set "PYEXE="
where py >nul 2>nul && set "PYEXE=py -3"
if "%PYEXE%"=="" ( where python >nul 2>nul && set "PYEXE=python" )
if "%PYEXE%"=="" (
  echo Python 3 not found. Please install: https://www.python.org/downloads/
  echo.
  pause
  goto :eof
)

echo [1/3] Installing/updating PyInstaller ...
%PYEXE% -m pip install --upgrade pyinstaller
if errorlevel 1 (
  echo ERROR: PyInstaller could not be installed.
  echo.
  pause
  goto :eof
)

echo [2/3] Building EXE ...
%PYEXE% -m PyInstaller --noconfirm --clean --onefile --noconsole ^
  --name "TekNerds C2PA" ^
  --icon "TN_AppIcon.ico" ^
  --add-binary "c2patool.exe;." ^
  --add-data "Licenses;Licenses" ^
  "c2pa_signer.py"

if not exist "dist\TekNerds C2PA.exe" (
  echo ERROR: build failed. Please check the output above.
  echo.
  pause
  goto :eof
)

echo [3/3] Placing the Licenses folder next to the EXE ...
if not exist "dist\Licenses" xcopy /E /I /Y "Licenses" "dist\Licenses" >nul

echo.
echo DONE ->  dist\TekNerds C2PA.exe
echo You can distribute this EXE (plus the "Licenses" folder).
echo Note: on first start Windows SmartScreen may warn
echo  ("More info" -> "Run anyway").
echo.
pause
