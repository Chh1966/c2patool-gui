# TekNerds C2PA – Windows 11 (English)

Local tool to **sign** and **verify** C2PA Content Credentials –
for files from DaVinci Resolve and other sources.

- **GUI idea:** TekNerds · Nils Voss & Christian Homburg
- **Base software:** [c2patool](https://github.com/contentauth/c2pa-rs) (C2PA) · © Adobe · Apache-2.0 / MIT
- Base framework created with Claude (Anthropic)

The tool runs entirely locally (server on `127.0.0.1`) and opens the interface
in your browser. **No** files are uploaded to the internet.

---

## Quick start (with Python)

1. **Double-click `Setup.bat`** – downloads `c2patool.exe` automatically.
   *(Optional: the app also downloads c2patool on first start if it is missing.)*
2. **Double-click `Start_C2PA_Tool.bat`** – the browser opens.
3. In the **Sign** tab drop a file, fill in the fields, *Apply seal*.

> Python is required. If you don't have it:
> [python.org/downloads](https://www.python.org/downloads/) – tick
> **"Add python.exe to PATH"** during setup.

Signed files are saved to **`Documents\C2PA-signed`**.

---

## Without Python: standalone EXE

To distribute the tool without a Python installation, build an EXE once:

1. Run `Setup.bat` (fetches `c2patool.exe`).
2. Run `build_exe.bat` → creates `dist\TekNerds C2PA.exe`.
3. Distribute the EXE + the `Licenses` folder. (On first start, if needed,
   SmartScreen: *"More info" → "Run anyway"*.)

---

## The three tabs

| Tab | Function |
|-----|----------|
| **Sign** | file + Author, Software, Version, Action (Created/Edited), AI use, optional Copyright/URL/own certificate |
| **Verify** | reads the manifest: Title, Author, Software, AI, Actions, Issuer, Signed time, validation |
| **Guide** | full install/usage + schematic + troubleshooting + licenses |

The **power button (⏻)** top right stops the server.

---

## Good to know

- **.mov** is only partially supported by c2patool → use **MP4**.
- **Audio:** only **WAV, MP3, M4A** can embed a C2PA manifest
  (AIFF/AAC/FLAC/OGG cannot). The tool warns on unsupported audio formats.
- Without your own certificate = **test certificate**: validly signed, but
  *"issuer not on the trust list"* – this is normal and **not an error**.
- **`assertion.dataHash.mismatch`** on verify = file was changed after signing
  → a real error.
- **Created** = original file · **Edited** = changed from existing material.

---

## Configuration

| Environment variable | Effect | Default |
|----------------------|--------|---------|
| `C2PA_PORT` | server port | `8731` |
| `C2PA_OUTPUT_DIR` | output folder | `Documents\C2PA-signed` |

---

## Project layout

```
c2patool-v0.26.67-EN/
  c2pa_signer.py        The app (Python standard library, no pip packages)
  Setup.bat             Downloads c2patool.exe (optional – the app fetches it otherwise)
  Start_C2PA_Tool.bat   Starts the app
  build_exe.bat         Optionally builds a standalone EXE
  TN_AppIcon.ico/.png   App icon
  Licenses/             LICENSE-APACHE, LICENSE-MIT, Notices-Rights-c2patool.txt
  README.md
```

---

## Licenses & rights

The signing engine **c2patool** (c2pa-rs) is © **Adobe** and dual licensed
under **Apache-2.0 OR MIT** (source: github.com/contentauth/c2pa-rs).
c2patool is bundled **unchanged**; the TekNerds interface is separate from it.
Full license texts in the **`Licenses`** folder.

For your own interface code you should still pick a license (e.g. MIT) –
c2patool is already covered separately.
