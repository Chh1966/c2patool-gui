#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# =====================================================================
#  TekNerds C2PA  -  Sign & verify C2PA Content Credentials
#  Windows-11-Version
#
#  GUI-Idee:        TekNerds  -  Nils Voss & Christian Homburg
#  Basis-Software:  c2patool (c2pa-rs)  -  (c) Adobe  -  Apache-2.0 / MIT
#  Grundgeruest erstellt mit Claude (Anthropic)
#
#  Reine Python-Standardbibliothek - keine pip-Pakete noetig.
#  Startet einen lokalen Server auf 127.0.0.1 und oeffnet den Browser.
# =====================================================================

import os
import sys
import re
import io
import json
import time
import html
import shutil
import socket
import tempfile
import subprocess
import threading
import zipfile
import tarfile
import platform
import webbrowser
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ---------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------
APP_NAME = "TekNerds C2PA"
VERSION  = "Build 1.1 (Windows, EN)"

# ---------------------------------------------------------------------
# Port (ueber Umgebungsvariable C2PA_PORT aenderbar)
# ---------------------------------------------------------------------
def _int_env(name, default):
    try:
        return int(os.environ.get(name, "").strip())
    except (ValueError, AttributeError):
        return default

PORT = _int_env("C2PA_PORT", 8731)
HOST = "127.0.0.1"

# ---------------------------------------------------------------------
# Ausgabeordner:  Dokumente\C2PA-signed
#   - per Umgebungsvariable C2PA_OUTPUT_DIR ueberschreibbar
# ---------------------------------------------------------------------
def _documents_dir():
    # Windows: %USERPROFILE%\Documents ; Fallback: ~/Documents
    home = os.path.expanduser("~")
    docs = os.path.join(home, "Documents")
    if not os.path.isdir(docs):
        # Manche deutschen Windows-Installationen nutzen "Dokumente"
        alt = os.path.join(home, "Dokumente")
        if os.path.isdir(alt):
            docs = alt
        else:
            docs = home
    return docs

OUTPUT_DIR = os.environ.get("C2PA_OUTPUT_DIR") or os.path.join(_documents_dir(), "C2PA-signed")

# ---------------------------------------------------------------------
# c2patool finden  (Windows: c2patool.exe)
#   Suchreihenfolge:
#     1. Ordner der App / des Skripts
#     2. Unterordner  bin\  und  _internal\
#     3. PATH
# ---------------------------------------------------------------------
def _app_dir():
    if getattr(sys, "frozen", False):           # PyInstaller-EXE
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def _data_dir():
    """Schreibbarer Ablageort, falls der App-Ordner schreibgeschuetzt ist."""
    base = os.environ.get("LOCALAPPDATA") or os.path.join(
        os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "TekNerds-C2PA")

def find_c2patool():
    names = ("c2patool.exe", "c2patool")
    base = _app_dir()

    # 1) Direkte Orte: App-Ordner, Datenordner, PyInstaller-Temp, Arbeitsverzeichnis
    direct_dirs = [base, _data_dir()]
    mei = getattr(sys, "_MEIPASS", None)
    if mei:
        direct_dirs.append(mei)
    cwd = os.getcwd()
    if cwd not in direct_dirs:
        direct_dirs.append(cwd)
    # gaengige Unterordner zu jedem dieser Orte
    for d in list(direct_dirs):
        for sub in ("bin", "_internal", os.path.join("_internal", "bin")):
            direct_dirs.append(os.path.join(d, sub))
    for d in direct_dirs:
        for n in names:
            p = os.path.join(d, n)
            if os.path.isfile(p):
                return p

    # 2) Rekursiv im App-Ordner und im Datenordner suchen
    #    (faengt entpackte Unterordner ab, z. B.
    #     c2patool-vX.Y.Z-x86_64-pc-windows-msvc\c2patool.exe)
    for root_dir in (base, _data_dir()):
        try:
            for root, _dirs, files in os.walk(root_dir):
                for n in names:
                    if n in files:
                        return os.path.join(root, n)
        except Exception:
            pass

    # 3) PATH
    for n in names:
        found = shutil.which(n)
        if found:
            return found
    return None


# ---------------------------------------------------------------------
# c2patool bei Bedarf automatisch herunterladen (nur Standardbibliothek)
# ---------------------------------------------------------------------
C2PATOOL_VERSION = "v0.26.67"

def _platform_asset():
    """(filename suffix pattern, is_zip) per platform."""
    if os.name == "nt":
        return "x86_64-pc-windows-msvc.zip", True
    if sys.platform == "darwin":
        return "universal-apple-darwin.zip", True
    return "x86_64-unknown-linux-gnu.tar.gz", False

def _github_latest_asset_url(suffix):
    """Find the newest c2patool release asset for this platform."""
    api = "https://api.github.com/repos/contentauth/c2pa-rs/releases?per_page=60"
    req = urllib.request.Request(api, headers={"User-Agent": "TekNerds-C2PA"})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.loads(r.read().decode("utf-8"))
    for rel in data:
        if not str(rel.get("tag_name", "")).startswith("c2patool-"):
            continue
        for a in rel.get("assets", []):
            if str(a.get("name", "")).endswith(suffix):
                return a.get("browser_download_url")
    return None

def _extract_binary(archive_path, is_zip, dest_dir):
    """c2patool(.exe) aus dem Archiv in dest_dir holen."""
    names = ("c2patool.exe", "c2patool")
    tmp = tempfile.mkdtemp(prefix="c2pa_dl_")
    try:
        if is_zip:
            with zipfile.ZipFile(archive_path) as z:
                z.extractall(tmp)
        else:
            with tarfile.open(archive_path) as t:
                t.extractall(tmp)
        for root, _dirs, files in os.walk(tmp):
            for n in names:
                if n in files:
                    os.makedirs(dest_dir, exist_ok=True)
                    target = os.path.join(dest_dir, n)
                    shutil.copyfile(os.path.join(root, n), target)
                    if os.name != "nt":
                        os.chmod(target, 0o755)
                    return target
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return None

def autofetch_c2patool():
    """Laedt c2patool, wenn es fehlt. Gibt den Pfad oder None zurueck."""
    suffix, is_zip = _platform_asset()
    pinned = ("https://github.com/contentauth/c2pa-rs/releases/download/"
              "c2patool-%s/c2patool-%s-%s" % (C2PATOOL_VERSION,
                                              C2PATOOL_VERSION, suffix))
    # Zielordner: App-Ordner, sonst Datenordner
    targets = [_app_dir(), _data_dir()]

    url = pinned
    archive = os.path.join(tempfile.gettempdir(),
                           "c2patool_dl" + (".zip" if is_zip else ".tar.gz"))
    try:
        try:
            _download(url, archive)
        except Exception:
            url = _github_latest_asset_url(suffix)
            if not url:
                return None
            _download(url, archive)
    except Exception as e:
        print("   Download failed:", e)
        return None

    for dest in targets:
        try:
            path = _extract_binary(archive, is_zip, dest)
            if path:
                try:
                    os.remove(archive)
                except OSError:
                    pass
                return path
        except (PermissionError, OSError):
            continue
    return None

def _download(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent": "TekNerds-C2PA"})
    with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f)


C2PATOOL = find_c2patool()


# ---------------------------------------------------------------------
# IPTC digitalSourceType (KI-Einsatz)
# ---------------------------------------------------------------------
IPTC = "http://cv.iptc.org/newscodes/digitalsourcetype/"
AI_SOURCE = {
    "keine":       None,                                    # kein KI-Hinweis
    "teilweise":   IPTC + "compositeWithTrainedAlgorithmicMedia",
    "vollstaendig":IPTC + "trainedAlgorithmicMedia",
}
AI_LABEL = {
    "keine":        "None",
    "teilweise":    "Partial AI",
    "vollstaendig": "Fully AI-generated",
}

# Unterstuetzte Formate (zur Vorab-Warnung; c2patool bettet nur diese ein)
AUDIO_OK = {".mp3", ".wav", ".m4a"}
AUDIO_ALL = {".mp3", ".wav", ".m4a", ".aac", ".aiff", ".aif",
             ".flac", ".ogg", ".alac"}


# ---------------------------------------------------------------------
# Manifest fuer c2patool bauen
# ---------------------------------------------------------------------
def build_manifest(fields, title):
    author    = (fields.get("author") or "").strip()
    software  = (fields.get("software") or "DaVinci Resolve").strip()
    swversion = (fields.get("version") or "").strip()
    action    = (fields.get("action") or "created").strip()      # created | edited
    ai        = (fields.get("ai") or "keine").strip()
    copyright_= (fields.get("copyright") or "").strip()
    url       = (fields.get("url") or "").strip()

    software_full = software + (" " + swversion if swversion else "")
    c2pa_action = "c2pa.edited" if action == "edited" else "c2pa.created"

    act = {
        "action": c2pa_action,
        "softwareAgent": {"name": software_full or software},
    }
    src = AI_SOURCE.get(ai)
    if src:
        act["digitalSourceType"] = src

    manifest = {
        "alg": "es256",
        "title": title,
        "claim_generator_info": [
            {"name": "TekNerds C2PA", "version": "1.0"}
        ],
        "assertions": [
            {
                "label": "c2pa.actions.v2",
                "data": {"actions": [act]},
            }
        ],
    }

    # CreativeWork (author / copyright / URL) only if something was entered
    cw = {"@context": "https://schema.org", "@type": "CreativeWork"}
    has_cw = False
    if author:
        cw["author"] = [{"@type": "Person", "name": author}]
        has_cw = True
    if copyright_:
        cw["copyrightNotice"] = copyright_
        has_cw = True
    if url:
        cw["url"] = url
        has_cw = True
    if has_cw:
        manifest["assertions"].append(
            {"label": "stds.schema-org.CreativeWork", "data": cw}
        )

    return manifest


# ---------------------------------------------------------------------
# Sign
# ---------------------------------------------------------------------
def sign_file(src_path, out_path, fields):
    if not C2PATOOL:
        return False, "c2patool.exe was not found. Please place it next to the app or run Setup."

    title = os.path.basename(src_path)
    manifest = build_manifest(fields, title)

    tmpdir = tempfile.mkdtemp(prefix="c2pa_")
    man_path = os.path.join(tmpdir, "manifest.json")

    env = dict(os.environ)
    # Optional own certificate / key (.pem)
    cert = (fields.get("cert") or "").strip()
    key  = (fields.get("key") or "").strip()
    if cert and key and os.path.isfile(cert) and os.path.isfile(key):
        env["C2PA_SIGN_CERT"] = cert
        env["C2PA_PRIVATE_KEY"] = key

    try:
        with open(man_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)

        cmd = [C2PATOOL, src_path, "-m", man_path, "-o", out_path, "--force"]
        p = subprocess.run(cmd, capture_output=True, text=True, env=env,
                           timeout=300)
        if p.returncode == 0 and os.path.isfile(out_path):
            return True, (p.stdout or "").strip()
        msg = (p.stderr or p.stdout or "Unknown error").strip()
        return False, msg
    except subprocess.TimeoutExpired:
        return False, "Timeout while signing (file too large?)."
    except Exception as e:
        return False, str(e)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


# ---------------------------------------------------------------------
# Verify (read manifest)
# ---------------------------------------------------------------------
def verify_file(src_path):
    if not C2PATOOL:
        return {"status": "error",
                "message": "c2patool.exe was not found."}
    try:
        p = subprocess.run([C2PATOOL, src_path], capture_output=True,
                           text=True, timeout=120)
    except subprocess.TimeoutExpired:
        return {"status": "error", "message": "Timeout while verifying."}
    except Exception as e:
        return {"status": "error", "message": str(e)}

    out = (p.stdout or "").strip()
    err = (p.stderr or "").strip()

    # No credentials?
    if not out or "No claim found" in out or "no claim" in out.lower() \
            or "No manifest" in out:
        return {"status": "none",
                "message": "No C2PA Content Credentials found."}

    try:
        data = json.loads(out)
    except json.JSONDecodeError:
        # c2patool prints plain text on some errors
        low = (out + " " + err).lower()
        if "no claim" in low or "not found" in low:
            return {"status": "none",
                    "message": "No C2PA Content Credentials found."}
        return {"status": "error", "message": (err or out)[:500]}

    return parse_manifest_report(data)


def _first(lst):
    return lst[0] if isinstance(lst, list) and lst else None


def parse_manifest_report(data):
    result = {
        "status": "ok",
        "title": "", "author": "", "software": "", "ai": "",
        "actions": [], "issuer": "", "time": "",
        "validation": [], "real_error": False,
    }

    active = data.get("active_manifest")
    manifests = data.get("manifests", {})
    man = manifests.get(active) if active else None
    if not man and manifests:
        man = next(iter(manifests.values()))
    if not man:
        return {"status": "none",
                "message": "No C2PA Content Credentials found."}

    result["title"]    = man.get("title", "") or ""
    result["software"] = ""
    cg = man.get("claim_generator_info") or []
    if cg and isinstance(cg, list):
        nm = cg[0].get("name", "")
        ver = cg[0].get("version", "")
        result["software"] = (nm + (" " + ver if ver else "")).strip()
    if not result["software"]:
        result["software"] = man.get("claim_generator", "") or ""

    sig = man.get("signature_info", {}) or {}
    result["issuer"] = sig.get("issuer", "") or sig.get("common_name", "") or ""
    result["time"]   = sig.get("time", "") or ""

    # Assertions durchgehen
    for a in man.get("assertions", []):
        label = a.get("label", "")
        adata = a.get("data", {}) or {}
        if label.startswith("c2pa.actions"):
            for act in adata.get("actions", []):
                name = act.get("action", "")
                sa = act.get("softwareAgent", "")
                if isinstance(sa, dict):
                    sa = sa.get("name", "")
                dst = act.get("digitalSourceType", "")
                txt = name
                if sa:
                    txt += " \u00b7 " + sa
                result["actions"].append(txt)
                if dst:
                    if "trainedAlgorithmicMedia" in dst and "composite" not in dst:
                        result["ai"] = AI_LABEL["vollstaendig"]
                    elif "composite" in dst:
                        result["ai"] = AI_LABEL["teilweise"]
        elif label.startswith("stds.schema-org.CreativeWork"):
            au = adata.get("author")
            a0 = _first(au) if isinstance(au, list) else au
            if isinstance(a0, dict):
                result["author"] = a0.get("name", "") or ""

    # Validierung auswerten
    vstatus = man.get("validation_status") or data.get("validation_status") or []
    benign = {"signingCredential.untrusted"}  # test certificate -> not an error
    real = []
    for v in vstatus:
        code = v.get("code", "") if isinstance(v, dict) else str(v)
        if code in benign:
            continue
        real.append(code)
    result["validation"] = real
    result["real_error"] = len(real) > 0
    if not result["ai"]:
        result["ai"] = AI_LABEL["keine"]
    return result


# ---------------------------------------------------------------------
# Multipart/form-data parsen  (binaer-sicher)
# ---------------------------------------------------------------------
def parse_multipart(body, boundary):
    """Liefert (fields:dict[str,str], files:dict[str,(filename,bytes)])."""
    fields, files = {}, {}
    delim = b"--" + boundary
    parts = body.split(delim)
    for part in parts:
        if not part or part in (b"--\r\n", b"--", b"\r\n"):
            continue
        if part.startswith(b"\r\n"):
            part = part[2:]
        if part.endswith(b"\r\n"):
            part = part[:-2]
        head_end = part.find(b"\r\n\r\n")
        if head_end == -1:
            continue
        raw_head = part[:head_end].decode("utf-8", "replace")
        content = part[head_end + 4:]
        # Disposition
        m_name = re.search(r'name="([^"]*)"', raw_head)
        if not m_name:
            continue
        name = m_name.group(1)
        m_file = re.search(r'filename="([^"]*)"', raw_head)
        if m_file:
            filename = m_file.group(1)
            files[name] = (filename, content)
        else:
            fields[name] = content.decode("utf-8", "replace")
    return fields, files


def safe_name(name):
    name = os.path.basename(name or "")
    name = re.sub(r'[^A-Za-z0-9._ \-()]', "_", name)
    return name or "datei"


def ext_of(name):
    return os.path.splitext(name or "")[1].lower()


# ---------------------------------------------------------------------
# TN-Logo als Inline-SVG (abgerundete schwarze Kachel, "TN" + "TekNerds")
# ---------------------------------------------------------------------
TN_LOGO_SVG = '''<svg width="46" height="46" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-label="TekNerds">
<rect x="2" y="2" width="96" height="96" rx="20" ry="20" fill="#000" stroke="#2a2a2a" stroke-width="1.5"/>
<text x="50" y="52" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-weight="800" font-size="40" fill="#fff" letter-spacing="-1">TN</text>
<text x="50" y="78" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-weight="600" font-size="13" fill="#bdbdbd" letter-spacing="0.5">TekNerds</text>
</svg>'''


def page_html():
    return PAGE_TEMPLATE.replace("{VERSION}", VERSION)\
                        .replace("{TN_LOGO}", TN_LOGO_SVG)\
                        .replace("{OUTDIR}", html.escape(OUTPUT_DIR))\
                        .replace("{TOOLSTATE}", "on" if C2PATOOL else "off")


# ---------------------------------------------------------------------
# Oberflaeche (HTML / CSS / JS)
# ---------------------------------------------------------------------
PAGE_TEMPLATE = r"""<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-store">
<title>TekNerds C2PA</title>
<style>
  :root{
    --yellow:#C8C800; --cyan:#17B8C9; --green:#1FAF3A;
    --magenta:#C21FC2; --red:#C8161D; --blue:#1E2FC4;
    --panel:#0c0c0c; --panel2:#141414; --bay:#1b1b1b;
    --line:#2a2a2a; --txt:#e8e8e8; --muted:#9a9a9a; --accent:#17B8C9;
  }
  *{box-sizing:border-box}
  html,body{margin:0;padding:0}
  body{
    font-family:"SF Mono",Menlo,Consolas,"DejaVu Sans Mono",monospace;
    color:var(--txt); min-height:100vh;
    background:
      linear-gradient(rgba(0,0,0,.04) 1px,transparent 1px) 0 0/22px 22px,
      linear-gradient(90deg,rgba(0,0,0,.04) 1px,transparent 1px) 0 0/22px 22px,
      #b9b9b9;
    display:flex; justify-content:center; padding:26px 14px 40px;
  }
  .console{width:100%; max-width:760px; background:var(--panel);
    border:1px solid var(--line); border-radius:14px; overflow:hidden;
    box-shadow:0 18px 50px rgba(0,0,0,.45);}
  /* Kopfleiste */
  header{display:flex; align-items:center; gap:13px; padding:14px 16px;
    background:linear-gradient(#181818,#101010); border-bottom:1px solid var(--line);}
  header .logo{flex:0 0 auto; display:flex}
  header .titles{flex:1 1 auto; min-width:0}
  header .titles .t1{font-weight:700; font-size:15px; letter-spacing:.5px}
  header .titles .t2{font-size:11px; color:var(--muted); margin-top:2px}
  header .led{width:10px;height:10px;border-radius:50%;
    box-shadow:0 0 7px currentColor;}
  header .led.on{color:#27d558;background:#27d558}
  header .led.off{color:#d33;background:#d33}
  .power{flex:0 0 auto; width:34px;height:34px;border-radius:50%;
    border:1px solid var(--line); background:#161616; color:#bbb;
    cursor:pointer; font-size:16px; line-height:1; display:flex;
    align-items:center; justify-content:center;}
  .power:hover{color:#fff; border-color:#444; background:#1d1d1d}
  /* SMPTE-Balken */
  .bars{display:flex; height:9px}
  .bars span{flex:1}
  .bars .b1{background:var(--yellow)} .bars .b2{background:var(--cyan)}
  .bars .b3{background:var(--green)}  .bars .b4{background:var(--magenta)}
  .bars .b5{background:var(--red)}    .bars .b6{background:var(--blue)}
  /* Tabs */
  .tabs{display:flex; background:var(--panel2); border-bottom:1px solid var(--line)}
  .tabs button{flex:1; background:none; border:0; color:var(--muted);
    padding:12px 8px; font-family:inherit; font-size:12.5px; letter-spacing:.6px;
    cursor:pointer; border-bottom:2px solid transparent;}
  .tabs button.active{color:#fff; border-bottom-color:var(--accent);
    background:#101010}
  .tabs button:hover{color:#ddd}
  /* Inhalt */
  .body{padding:18px 18px 8px}
  .pane{display:none} .pane.active{display:block}
  .drop{border:1.5px dashed #3a3a3a; border-radius:10px; background:#0e0e0e;
    padding:26px 16px; text-align:center; color:var(--muted); cursor:pointer;
    transition:.15s;}
  .drop:hover,.drop.hot{border-color:var(--accent); color:#ddd; background:#0f1414}
  .drop .fn{color:#fff; word-break:break-all}
  label{display:block; font-size:11px; color:var(--muted); margin:12px 0 4px;
    letter-spacing:.5px; text-transform:uppercase}
  input[type=text],select{width:100%; background:var(--bay);
    border:1px solid var(--line); color:var(--txt); border-radius:7px;
    padding:9px 10px; font-family:inherit; font-size:13px;}
  input::placeholder{color:#666}
  input:focus,select:focus{outline:none; border-color:var(--accent)}
  .row{display:flex; gap:12px} .row>div{flex:1}
  .seg{display:flex; gap:0; border:1px solid var(--line); border-radius:7px;
    overflow:hidden}
  .seg button{flex:1; background:var(--bay); border:0; color:var(--muted);
    padding:9px; font-family:inherit; font-size:12.5px; cursor:pointer}
  .seg button.on{background:var(--accent); color:#001}
  .hint{font-size:11px; color:#7d7d7d; margin-top:6px; line-height:1.5}
  details{margin-top:14px; border:1px solid var(--line); border-radius:7px;
    background:#0e0e0e}
  details summary{cursor:pointer; padding:9px 11px; font-size:12px; color:var(--muted)}
  .seal{width:100%; margin-top:18px; padding:14px; border:0; border-radius:9px;
    background:linear-gradient(#1c8fa0,#0f6f7d); color:#fff; font-family:inherit;
    font-size:15px; font-weight:700; letter-spacing:2px; cursor:pointer;
    box-shadow:0 0 0 1px #17b8c9 inset, 0 6px 16px rgba(23,184,201,.25)}
  .seal:hover{filter:brightness(1.08)}
  .seal:disabled{opacity:.5; cursor:default}
  /* Ergebnis */
  .result{margin-top:16px; border-radius:9px; padding:14px 15px; display:none;
    font-size:13px; line-height:1.6}
  .result.show{display:block}
  .result.good{background:#0e2014; border:1px solid #1f6f3a}
  .result.bad{background:#23110f; border:1px solid #7a2420}
  .result.info{background:#101a1d; border:1px solid #1f5f6a}
  .result h4{margin:0 0 8px; font-size:13px; letter-spacing:1px}
  .result .k{color:var(--muted); display:inline-block; min-width:96px}
  .result .v{color:#fff}
  .result .acts{color:#cfcfcf}
  .btnrow{margin-top:12px; display:flex; gap:9px; flex-wrap:wrap}
  .btnrow a,.btnrow button{font-family:inherit; font-size:12px; cursor:pointer;
    text-decoration:none; padding:8px 12px; border-radius:6px;
    border:1px solid var(--line); background:#161616; color:#ddd}
  .btnrow a:hover,.btnrow button:hover{border-color:#444; color:#fff}
  /* Guide */
  .guide h3{font-size:13px; color:var(--accent); letter-spacing:1px;
    margin:18px 0 6px}
  .guide h3:first-child{margin-top:4px}
  .guide p,.guide li{font-size:12.5px; color:#cfcfcf; line-height:1.65}
  .guide ul{margin:4px 0 4px 18px; padding:0}
  .guide code{background:#1b1b1b; padding:1px 6px; border-radius:4px;
    color:#9fe0e8; font-size:12px}
  .schema{width:100%; border:1px solid var(--line); border-radius:9px;
    margin:6px 0 4px; background:#0e0e0e}
  /* Fuss */
  footer{padding:13px 16px; border-top:1px solid var(--line);
    background:var(--panel2); color:#6f6f6f; font-size:10.5px; line-height:1.7}
  footer .v{color:#9a9a9a}
  .overlay{position:fixed; inset:0; background:#0a0a0a;
    display:none; align-items:center; justify-content:center; color:#ddd;
    font-size:15px; text-align:center; padding:30px}
  .overlay.show{display:flex}
</style>
</head>
<body>
<div class="console">
  <header>
    <div class="logo">{TN_LOGO}</div>
    <div class="titles">
      <div class="t1">TekNerds</div>
      <div class="t2">C2PA &middot; Sign &amp; Verify &middot; {VERSION}</div>
    </div>
    <div class="led {TOOLSTATE}" title="c2patool status"></div>
    <button class="power" id="power" title="Stop server">&#9211;</button>
  </header>
  <div class="bars"><span class="b1"></span><span class="b2"></span><span class="b3"></span><span class="b4"></span><span class="b5"></span><span class="b6"></span></div>

  <div class="tabs">
    <button data-tab="sign" class="active">SIGN</button>
    <button data-tab="verify">VERIFY</button>
    <button data-tab="guide">GUIDE</button>
  </div>

  <div class="body">
    <!-- SIGN -->
    <div class="pane active" id="pane-sign">
      <div class="drop" id="dropS"><div id="dropStxt">Drop file here<br>or click</div></div>
      <input type="file" id="fileS" style="display:none">
      <div id="audioWarn" class="hint" style="display:none;color:#d8a13a"></div>

      <div class="row">
        <div>
          <label>Author</label>
          <input type="text" id="author" placeholder="Voss &amp; Homburg">
        </div>
        <div>
          <label>Software</label>
          <input type="text" id="software" value="DaVinci Resolve">
        </div>
      </div>
      <div class="row">
        <div>
          <label>Version (optional)</label>
          <input type="text" id="version" placeholder="e.g. 19.1">
        </div>
        <div>
          <label>AI use</label>
          <select id="ai">
            <option value="keine">None</option>
            <option value="teilweise">Partial AI</option>
            <option value="vollstaendig">Fully AI-generated</option>
          </select>
        </div>
      </div>

      <label>Action</label>
      <div class="seg" id="segAction">
        <button data-a="created" class="on">Created</button>
        <button data-a="edited">Edited</button>
      </div>
      <div class="hint">Created = original file &middot; Edited = changed from existing material.</div>

      <details>
        <summary>More details (copyright, URL, own certificate)</summary>
        <div style="padding:6px 11px 12px">
          <div class="row">
            <div>
              <label>Copyright</label>
              <input type="text" id="copyright" placeholder="&copy; 2026 Voss &amp; Homburg">
            </div>
            <div>
              <label>URL</label>
              <input type="text" id="url" placeholder="https://...">
            </div>
          </div>
          <div class="row">
            <div>
              <label>Certificate (.pem, path)</label>
              <input type="text" id="cert" placeholder="C:\\path\\cert.pem">
            </div>
            <div>
              <label>Key (.pem, path)</label>
              <input type="text" id="key" placeholder="C:\\path\\key.pem">
            </div>
          </div>
          <div class="hint">Without your own certificate, c2patool&rsquo;s test certificate is used (validly signed, but &bdquo;issuer not on the trust list&ldquo;).</div>
        </div>
      </details>

      <button class="seal" id="signBtn" disabled>APPLY SEAL</button>
      <div class="result" id="resS"></div>
    </div>

    <!-- VERIFY -->
    <div class="pane" id="pane-verify">
      <div class="drop" id="dropV"><div id="dropVtxt">Drop file to verify<br>or click</div></div>
      <input type="file" id="fileV" style="display:none">
      <button class="seal" id="verifyBtn" disabled>VERIFY</button>
      <div class="result" id="resV"></div>
    </div>

    <!-- GUIDE -->
    <div class="pane guide" id="pane-guide"></div>
  </div>

  <footer>
    <div>GUI idea: <span class="v">TekNerds &middot; Nils Voss &amp; Christian Homburg</span> &middot; Base software: <span class="v">c2patool (C2PA)</span></div>
    <div>c2patool &copy; Adobe &middot; Apache-2.0 / MIT &middot; License texts: Guide &amp; &bdquo;Licenses&ldquo; folder &middot; <span class="v">{VERSION}</span></div>
  </footer>
</div>

<div class="overlay" id="overlay"></div>
<script>
const $=s=>document.querySelector(s);
const AUDIO_OK=["mp3","wav","m4a"];
const AUDIO_ALL=["mp3","wav","m4a","aac","aiff","aif","flac","ogg","alac"];

// Tabs
document.querySelectorAll('.tabs button').forEach(b=>{
  b.onclick=()=>{
    document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.pane').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    $('#pane-'+b.dataset.tab).classList.add('active');
  };
});

// Aktion-Umschalter
let action='created';
document.querySelectorAll('#segAction button').forEach(b=>{
  b.onclick=()=>{
    document.querySelectorAll('#segAction button').forEach(x=>x.classList.remove('on'));
    b.classList.add('on'); action=b.dataset.a;
  };
});

// File selection (sign)
let fileS=null, fileV=null;
function wireDrop(dropId, inputId, txtId, onFile){
  const drop=$(dropId), inp=$(inputId), txt=$(txtId);
  drop.onclick=()=>inp.click();
  inp.onchange=()=>{ if(inp.files[0]) onFile(inp.files[0], txt); };
  ['dragover','dragenter'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.add('hot');}));
  ['dragleave','drop'].forEach(e=>drop.addEventListener(e,ev=>{ev.preventDefault();drop.classList.remove('hot');}));
  drop.addEventListener('drop',ev=>{ if(ev.dataTransfer.files[0]) onFile(ev.dataTransfer.files[0], txt); });
}
function ext(n){const p=(n||"").split('.');return p.length>1?p.pop().toLowerCase():"";}

wireDrop('#dropS','#fileS','#dropStxt',(f,txt)=>{
  fileS=f; txt.innerHTML='<span class="fn">'+f.name+'</span>';
  $('#signBtn').disabled=false;
  const e=ext(f.name); const w=$('#audioWarn');
  if(AUDIO_ALL.includes(e) && !AUDIO_OK.includes(e)){
    w.style.display='block';
    w.textContent='Note: c2patool only embeds C2PA into WAV, MP3 and M4A. This audio format ('+e.toUpperCase()+') will not be embedded \u2013 please export as WAV or MP3.';
  } else { w.style.display='none'; }
});
wireDrop('#dropV','#fileV','#dropVtxt',(f,txt)=>{
  fileV=f; txt.innerHTML='<span class="fn">'+f.name+'</span>';
  $('#verifyBtn').disabled=false;
});

// Sign
$('#signBtn').onclick=async()=>{
  if(!fileS) return;
  const btn=$('#signBtn'); btn.disabled=true; const old=btn.textContent;
  btn.textContent='SIGNING \u2026';
  const fd=new FormData();
  fd.append('file',fileS);
  ['author','software','version','ai','copyright','url','cert','key'].forEach(id=>fd.append(id,$('#'+id).value));
  fd.append('action',action);
  try{
    const r=await fetch('/sign',{method:'POST',body:fd});
    const j=await r.json();
    const box=$('#resS'); box.className='result show '+(j.ok?'good':'bad');
    if(j.ok){
      box.innerHTML='<h4>&#10003; SEALED</h4>'+
        '<div><span class="k">File</span><span class="v">'+esc(j.outname)+'</span></div>'+
        '<div><span class="k">Folder</span><span class="v">'+esc(j.outdir)+'</span></div>'+
        '<div class="btnrow"><button onclick="openFolder()">Open folder</button>'+
        '<a href="/download?name='+encodeURIComponent(j.outname)+'">Download</a></div>'+
        '<div class="hint">The signed file is always saved automatically in the folder.</div>';
    } else {
      box.innerHTML='<h4>&#9888; ERROR</h4><div class="acts">'+esc(j.message||'Unknown')+'</div>';
    }
  }catch(e){
    const box=$('#resS'); box.className='result show bad';
    box.innerHTML='<h4>&#9888; ERROR</h4><div class="acts">'+esc(e.message)+'</div>';
  }
  btn.textContent=old; btn.disabled=false;
};

// Verify
$('#verifyBtn').onclick=async()=>{
  if(!fileV) return;
  const btn=$('#verifyBtn'); btn.disabled=true; const old=btn.textContent;
  btn.textContent='VERIFYING \u2026';
  const fd=new FormData(); fd.append('file',fileV);
  try{
    const r=await fetch('/verify',{method:'POST',body:fd});
    const j=await r.json();
    const box=$('#resV');
    if(j.status==='ok'){
      const bad=j.real_error;
      box.className='result show '+(bad?'bad':'good');
      let h=bad?'<h4>&#9888; VALIDATION FAILED</h4>':'<h4>&#10003; VALIDLY SIGNED</h4>';
      h+=row('Title',j.title);
      h+=row('Author',j.author||'\u2013');
      h+=row('Software',j.software||'\u2013');
      h+=row('AI',j.ai||'\u2013');
      if(j.actions&&j.actions.length) h+='<div><span class="k">Actions</span><span class="acts">'+j.actions.map(esc).join('<br><span class="k"></span>')+'</span></div>';
      h+=row('Issuer',j.issuer||'\u2013');
      if(j.time) h+=row('Signed on',j.time);
      if(bad) h+='<div class="acts" style="margin-top:8px;color:#e6a">'+j.validation.map(esc).join(', ')+'</div>';
      h+='<div class="hint">Issuer trust (trust list) is not checked locally. Test certificate = &bdquo;issuer not on the trust list&ldquo; is normal. Full trust check: verify.contentauthenticity.org</div>';
      box.innerHTML=h;
    } else if(j.status==='none'){
      box.className='result show info';
      box.innerHTML='<h4>NO CREDENTIALS</h4><div class="acts">This file has no C2PA Content Credentials.</div>';
    } else {
      box.className='result show bad';
      box.innerHTML='<h4>&#9888; ERROR</h4><div class="acts">'+esc(j.message||'Unknown')+'</div>';
    }
  }catch(e){
    const box=$('#resV'); box.className='result show bad';
    box.innerHTML='<h4>&#9888; ERROR</h4><div class="acts">'+esc(e.message)+'</div>';
  }
  btn.textContent=old; btn.disabled=false;
};

function row(k,v){return '<div><span class="k">'+k+'</span><span class="v">'+esc(v||'')+'</span></div>';}
function esc(s){return (s+'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
async function openFolder(){ try{await fetch('/openfolder');}catch(e){} }

// Power -> Server beenden
$('#power').onclick=async()=>{
  if(!confirm('Stop server? The app will close.')) return;
  try{ await fetch('/quit'); }catch(e){}
  $('#overlay').classList.add('show');
  $('#overlay').textContent='Server stopped \u2013 you can close this window now.';
};

// load guide
fetch('/guide').then(r=>r.text()).then(t=>{$('#pane-guide').innerHTML=t;});
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------
# Guide (HTML fragment for the tab)
# ---------------------------------------------------------------------
SCHEMA_SVG = r"""<svg class="schema" viewBox="0 0 620 250" xmlns="http://www.w3.org/2000/svg">
<rect x="40" y="14" width="540" height="210" rx="10" fill="#0c0c0c" stroke="#2a2a2a"/>
<rect x="40" y="14" width="540" height="40" rx="10" fill="#161616"/>
<rect x="52" y="24" width="22" height="22" rx="5" fill="#000" stroke="#333"/>
<text x="63" y="39" text-anchor="middle" font-size="10" fill="#fff" font-family="monospace">TN</text>
<text x="86" y="32" font-size="11" fill="#fff" font-family="monospace">TekNerds</text>
<text x="86" y="45" font-size="8" fill="#999" font-family="monospace">C2PA &#183; BUILD x</text>
<circle cx="556" cy="34" r="8" fill="#161616" stroke="#333"/>
<text x="556" y="38" text-anchor="middle" font-size="9" fill="#bbb">&#9211;</text>
<rect x="40" y="54" width="90" height="6" fill="#C8C800"/><rect x="130" y="54" width="90" height="6" fill="#17B8C9"/>
<rect x="220" y="54" width="90" height="6" fill="#1FAF3A"/><rect x="310" y="54" width="90" height="6" fill="#C21FC2"/>
<rect x="400" y="54" width="90" height="6" fill="#C8161D"/><rect x="490" y="54" width="90" height="6" fill="#1E2FC4"/>
<text x="100" y="78" text-anchor="middle" font-size="9" fill="#17B8C9" font-family="monospace">SIGN</text>
<text x="230" y="78" text-anchor="middle" font-size="9" fill="#888" font-family="monospace">VERIFY</text>
<text x="360" y="78" text-anchor="middle" font-size="9" fill="#888" font-family="monospace">GUIDE</text>
<rect x="60" y="92" width="500" height="60" rx="8" fill="#0e0e0e" stroke="#3a3a3a" stroke-dasharray="4 3"/>
<text x="310" y="126" text-anchor="middle" font-size="11" fill="#aaa" font-family="monospace">Drop file here / click</text>
<rect x="60" y="166" width="500" height="34" rx="7" fill="#0f6f7d"/>
<text x="310" y="188" text-anchor="middle" font-size="12" fill="#fff" font-family="monospace" letter-spacing="2">APPLY SEAL</text>
<text x="60" y="216" font-size="9" fill="#888" font-family="monospace">Output: Documents\\C2PA-signed</text>
</svg>"""

GUIDE_HTML = (
"<h3>What the tool looks like</h3>" + SCHEMA_SVG +
"<p>Top left the TN logo, top right the power button (&#9211;) to quit. "
"Below it the three tabs <b>Sign / Verify / Guide</b>, the drop area "
"and the seal button. Signed files are saved automatically to "
"<code>Documents\\C2PA-signed</code>.</p>"

"<h3>What you need</h3>"
"<ul>"
"<li>Windows 10/11</li>"
"<li><b>c2patool.exe</b> (signing engine) &#8211; the app downloads it "
"automatically on first start if it is missing.</li>"
"<li>Python is only needed when you run the app as a script "
"(the EXE version does not need Python).</li>"
"</ul>"

"<h3>1 &middot; Install</h3>"
"<ul>"
"<li>Put the folder <code>c2patool-v0.26.67</code> in a fixed place "
"(e.g. <code>C:\\Program Files</code> or the Desktop).</li>"
"<li>Start by double-clicking <code>Start_C2PA_Tool.bat</code> or the EXE.</li>"
"<li>On first start Windows SmartScreen may warn &#8211; "
"&bdquo;More info&ldquo; &rarr; &bdquo;Run anyway&ldquo;.</li>"
"</ul>"

"<h3>2 &middot; Sign</h3>"
"<ul>"
"<li>In the <b>Sign</b> tab drop a file (ideally MP4, JPG, PNG, WAV, MP3).</li>"
"<li>Enter author, software, action and AI use.</li>"
"<li><b>Apply seal</b> &rarr; the file is saved to <code>Documents\\C2PA-signed</code> "
"(button &bdquo;Open folder&ldquo;).</li>"
"</ul>"

"<h3>3 &middot; Verify</h3>"
"<ul><li>In the <b>Verify</b> tab drop a file &rarr; it shows author, software, "
"AI status, edit history and issuer.</li></ul>"

"<h3>Good to know</h3>"
"<ul>"
"<li><b>.mov</b> is only partially supported by c2patool &rarr; use <b>MP4</b>.</li>"
"<li><b>Audio</b>: only <b>WAV, MP3, M4A</b> can embed a C2PA manifest "
"(AIFF/AAC/FLAC/OGG cannot).</li>"
"<li>Without your own certificate = test certificate: validly signed, but "
"&bdquo;issuer not on the trust list&ldquo; &#8211; this is normal.</li>"
"<li><b>Created</b> = original file &middot; <b>Edited</b> = changed from existing material.</li>"
"<li><b>assertion.dataHash.mismatch</b> on verify = file was changed after signing (a real error).</li>"
"<li>Stop the server: power button (&#9211;) top right.</li>"
"<li>Full trust check: verify.contentauthenticity.org</li>"
"</ul>"

"<h3>If something goes wrong</h3>"
"<ul>"
"<li><b>Browser does not open:</b> open <code>http://127.0.0.1:8731</code> manually.</li>"
"<li><b>&bdquo;c2patool not found&ldquo;:</b> <code>c2patool.exe</code> must sit next to the app "
"(or in a <code>bin</code> subfolder) &#8211; or let the app download it / run Setup again.</li>"
"<li><b>Port in use / old view:</b> use the power button or press "
"<code>Ctrl+Shift+R</code> in the browser.</li>"
"<li><b>Download button does nothing:</b> never mind &#8211; the file is always in "
"<code>Documents\\C2PA-signed</code> (button &bdquo;Open folder&ldquo;).</li>"
"</ul>"

"<h3>Licenses &amp; rights</h3>"
"<p>The signing engine <b>c2patool</b> (c2pa-rs) is &copy; <b>Adobe</b> and dual "
"licensed under <b>Apache-2.0</b> OR <b>MIT</b>. "
"Source: github.com/contentauth/c2pa-rs. c2patool is bundled unchanged; "
"the TekNerds interface is separate from it. The full license texts are in "
"the <b>&bdquo;Licenses&ldquo;</b> folder (LICENSE-APACHE, LICENSE-MIT, "
"Notices-Rights-c2patool.txt).</p>"
"<p style='color:#7d7d7d'>GUI idea: TekNerds &middot; Nils Voss &amp; Christian Homburg. "
"Base framework created with Claude (Anthropic).</p>"
)


# ---------------------------------------------------------------------
# HTTP-Handler
# ---------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "TekNerdsC2PA/1.0"

    def log_message(self, *a):
        pass  # ruhig

    def _send(self, code, body, ctype="text/html; charset=utf-8"):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False),
                   "application/json; charset=utf-8")

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(length) if length else b""

    # --------------------- GET ---------------------
    def do_GET(self):
        path = self.path.split("?", 1)[0]
        if path == "/":
            self._send(200, page_html())
        elif path == "/guide":
            self._send(200, GUIDE_HTML)
        elif path == "/openfolder":
            try:
                os.makedirs(OUTPUT_DIR, exist_ok=True)
                if os.name == "nt":
                    os.startfile(OUTPUT_DIR)  # noqa
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", OUTPUT_DIR])
                else:
                    subprocess.Popen(["xdg-open", OUTPUT_DIR])
            except Exception:
                pass
            self._json({"ok": True})
        elif path == "/download":
            self._handle_download()
        elif path == "/quit":
            self._json({"ok": True})
            threading.Thread(target=_shutdown, daemon=True).start()
        else:
            self._send(404, "not found")

    def _handle_download(self):
        from urllib.parse import urlparse, parse_qs
        q = parse_qs(urlparse(self.path).query)
        name = safe_name((q.get("name") or [""])[0])
        fp = os.path.join(OUTPUT_DIR, name)
        if not name or not os.path.isfile(fp):
            self._send(404, "File not found")
            return
        with open(fp, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Disposition",
                         'attachment; filename="%s"' % name)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # --------------------- POST ---------------------
    def do_POST(self):
        path = self.path.split("?", 1)[0]
        ctype = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in ctype:
            self._json({"ok": False, "message": "Expected multipart"}, 400)
            return
        m = re.search(r"boundary=([^;]+)", ctype)
        if not m:
            self._json({"ok": False, "message": "Boundary missing"}, 400)
            return
        boundary = m.group(1).strip().strip('"').encode("utf-8")
        body = self._read_body()
        fields, files = parse_multipart(body, boundary)

        if "file" not in files:
            self._json({"ok": False, "message": "No file received"}, 400)
            return
        filename, content = files["file"]
        filename = safe_name(filename)

        if path == "/sign":
            self._do_sign(filename, content, fields)
        elif path == "/verify":
            self._do_verify(filename, content)
        else:
            self._send(404, "not found")

    def _do_sign(self, filename, content, fields):
        tmpdir = tempfile.mkdtemp(prefix="c2pa_in_")
        src = os.path.join(tmpdir, filename)
        try:
            with open(src, "wb") as f:
                f.write(content)
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            base, ext = os.path.splitext(filename)
            outname = base + "_c2pa" + ext
            outpath = os.path.join(OUTPUT_DIR, outname)
            ok, msg = sign_file(src, outpath, fields)
            if ok:
                self._json({"ok": True, "outname": outname,
                            "outdir": OUTPUT_DIR, "message": msg})
            else:
                self._json({"ok": False, "message": msg})
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _do_verify(self, filename, content):
        tmpdir = tempfile.mkdtemp(prefix="c2pa_vf_")
        src = os.path.join(tmpdir, filename)
        try:
            with open(src, "wb") as f:
                f.write(content)
            res = verify_file(src)
            self._json(res)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)


# ---------------------------------------------------------------------
# Server-Start / -Stop
# ---------------------------------------------------------------------
_httpd = None

def _shutdown():
    global _httpd
    time.sleep(0.4)
    try:
        if _httpd:
            _httpd.shutdown()
    except Exception:
        pass
    os._exit(0)

def _port_free(host, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        s.close()

def main():
    global _httpd, PORT, C2PATOOL
    # c2patool fehlt? -> automatisch herunterladen
    if not C2PATOOL:
        print("c2patool not found - downloading it once ...")
        C2PATOOL = autofetch_c2patool() or find_c2patool()
        if C2PATOOL:
            print("   OK:", C2PATOOL)
        else:
            print("   Could not download c2patool (internet?).")
            print("   You can also place c2patool.exe next to this app manually:")
            print("   https://github.com/contentauth/c2pa-rs/releases  (Filter: c2patool)")

    # Freien Port suchen, falls belegt
    port = PORT
    for _ in range(20):
        if _port_free(HOST, port):
            break
        port += 1
    PORT = port

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    _httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    url = "http://%s:%d" % (HOST, PORT)

    print("=" * 54)
    print(" %s  %s" % (APP_NAME, VERSION))
    print(" running at:        %s" % url)
    print(" Signed files:      %s" % OUTPUT_DIR)
    print(" c2patool:          %s" % (C2PATOOL or "NOT FOUND"))
    print(" Quit:              Power button or Ctrl+C")
    print("=" * 54)

    if "--no-browser" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        _httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
        os._exit(0)


if __name__ == "__main__":
    main()
