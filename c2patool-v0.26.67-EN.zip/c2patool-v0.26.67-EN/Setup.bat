@echo off
chcp 65001 >nul
title TekNerds C2PA - Setup
cd /d "%~dp0"

echo ================================================================
echo   TekNerds C2PA  -  Setup (Windows)
echo   Downloads the signing engine c2patool.exe.
echo ================================================================
echo.

if exist "c2patool.exe" (
  echo c2patool.exe is already present - nothing to do.
  echo Start the tool with:  Start_C2PA_Tool.bat
  echo.
  pause
  goto :eof
)

set "VER=v0.26.67"
set "ZIP=c2patool-%VER%-x86_64-pc-windows-msvc.zip"
set "URL=https://github.com/contentauth/c2pa-rs/releases/download/c2patool-%VER%/%ZIP%"

echo [1/3] Downloading c2patool %VER% ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "try { Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP%' -UseBasicParsing; Write-Host '   OK' }" ^
  "catch { Write-Host '   Pinned version not reachable - searching latest ...';" ^
  "  $rels = Invoke-RestMethod -Uri 'https://api.github.com/repos/contentauth/c2pa-rs/releases?per_page=60' -Headers @{ 'User-Agent'='TekNerds' };" ^
  "  $asset = $rels | Where-Object { $_.tag_name -like 'c2patool-*' } | ForEach-Object { $_.assets } | Where-Object { $_.name -like '*x86_64-pc-windows-msvc.zip' } | Select-Object -First 1;" ^
  "  if (-not $asset) { Write-Host '   ERROR: no Windows asset found.'; exit 1 }" ^
  "  Write-Host ('   Downloading ' + $asset.name);" ^
  "  Invoke-WebRequest -Uri $asset.browser_download_url -OutFile '%ZIP%' -UseBasicParsing }"

if not exist "%ZIP%" (
  echo.
  echo ERROR: download failed.
  echo Please download c2patool manually from:
  echo   https://github.com/contentauth/c2pa-rs/releases  (filter: c2patool)
  echo Extract  ..._x86_64-pc-windows-msvc.zip  and place c2patool.exe
  echo into this folder.
  echo.
  pause
  goto :eof
)

echo [2/3] Extracting ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Expand-Archive -Path '%ZIP%' -DestinationPath '_c2pa_tmp' -Force"

echo [3/3] Placing c2patool.exe ...
for /r "_c2pa_tmp" %%F in (c2patool.exe) do copy /Y "%%F" "c2patool.exe" >nul
rmdir /S /Q "_c2pa_tmp" 2>nul
del /Q "%ZIP%" 2>nul

if exist "c2patool.exe" (
  echo.
  echo DONE - c2patool.exe is installed.
  echo Now start the tool with:  Start_C2PA_Tool.bat
) else (
  echo.
  echo ERROR: c2patool.exe could not be extracted.
)
echo.
pause
