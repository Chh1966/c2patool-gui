@echo off
chcp 65001 >nul
title TekNerds C2PA
cd /d "%~dp0"

rem Python finden:  py-Launcher bevorzugt, sonst python
set "PYEXE="
where py >nul 2>nul && set "PYEXE=py -3"
if "%PYEXE%"=="" ( where python >nul 2>nul && set "PYEXE=python" )

if "%PYEXE%"=="" (
  echo Python 3 wurde nicht gefunden.
  echo Bitte Python von https://www.python.org/downloads/ installieren
  echo ^(beim Setup "Add python.exe to PATH" anhaken^),
  echo ODER die EXE-Version verwenden ^(siehe build_exe.bat / README^).
  echo.
  pause
  goto :eof
)

echo Starte TekNerds C2PA ... (dieses Fenster offen lassen)
echo Fehlt c2patool, wird es beim Start automatisch geladen.
echo Beenden: Power-Knopf in der App oder hier Strg+C.
echo.
%PYEXE% "c2pa_signer.py"
pause
