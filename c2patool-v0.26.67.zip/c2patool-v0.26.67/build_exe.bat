@echo off
chcp 65001 >nul
title TekNerds C2PA - EXE bauen
cd /d "%~dp0"

echo ================================================================
echo   TekNerds C2PA  -  eigenstaendige EXE bauen (optional)
echo   Ergebnis:  dist\TekNerds C2PA.exe  (laeuft ohne Python)
echo ================================================================
echo.
echo Voraussetzung: Python 3 + Internet (fuer PyInstaller).
echo c2patool.exe wird mit eingebettet.
echo.

if not exist "c2patool.exe" (
  echo c2patool.exe fehlt - bitte zuerst Setup.bat ausfuehren.
  echo.
  pause
  goto :eof
)

set "PYEXE="
where py >nul 2>nul && set "PYEXE=py -3"
if "%PYEXE%"=="" ( where python >nul 2>nul && set "PYEXE=python" )
if "%PYEXE%"=="" (
  echo Python 3 nicht gefunden. Bitte installieren: https://www.python.org/downloads/
  echo.
  pause
  goto :eof
)

echo [1/3] PyInstaller installieren/aktualisieren ...
%PYEXE% -m pip install --upgrade pyinstaller
if errorlevel 1 (
  echo FEHLER: PyInstaller konnte nicht installiert werden.
  echo.
  pause
  goto :eof
)

echo [2/3] EXE bauen ...
%PYEXE% -m PyInstaller --noconfirm --clean --onefile --noconsole ^
  --name "TekNerds C2PA" ^
  --icon "TN_AppIcon.ico" ^
  --add-binary "c2patool.exe;." ^
  --add-data "Lizenzen;Lizenzen" ^
  "c2pa_signer.py"

if not exist "dist\TekNerds C2PA.exe" (
  echo FEHLER: Build fehlgeschlagen. Bitte Ausgabe oben pruefen.
  echo.
  pause
  goto :eof
)

echo [3/3] Lizenzordner neben die EXE legen ...
if not exist "dist\Lizenzen" xcopy /E /I /Y "Lizenzen" "dist\Lizenzen" >nul

echo.
echo FERTIG ->  dist\TekNerds C2PA.exe
echo Diese EXE (plus Ordner "Lizenzen") kannst du weitergeben.
echo Hinweis: Beim ersten Start kann Windows SmartScreen warnen
echo  ("Weitere Informationen" -> "Trotzdem ausfuehren").
echo.
pause
