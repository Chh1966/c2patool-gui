# TekNerds C2PA – Windows 11

Lokales Tool zum **Signieren** und **Prüfen** von C2PA Content Credentials –
für Dateien aus DaVinci Resolve und anderen Quellen.

- **GUI-Idee:** TekNerds · Nils Voss & Christian Homburg
- **Basis-Software:** [c2patool](https://github.com/contentauth/c2pa-rs) (C2PA) · © Adobe · Apache-2.0 / MIT
- Grundgerüst erstellt mit Claude (Anthropic)

Das Tool läuft komplett lokal (Server auf `127.0.0.1`) und öffnet die Oberfläche
im Browser. Es werden **keine** Dateien ins Internet geladen.

---

## Schnellstart (mit Python)

1. **`Setup.bat` doppelklicken** – lädt `c2patool.exe` automatisch herunter.
   *(Optional: Die App lädt c2patool beim ersten Start auch selbst, falls es fehlt.)*
2. **`Start_C2PA_Tool.bat` doppelklicken** – der Browser öffnet sich.
3. Im Tab **Signieren** eine Datei ablegen, Felder ausfüllen, *Siegel anbringen*.

> Python wird benötigt. Falls nicht vorhanden:
> [python.org/downloads](https://www.python.org/downloads/) – beim Setup
> **„Add python.exe to PATH"** anhaken.

Signierte Dateien landen in **`Dokumente\C2PA-signed`**.

---

## Ohne Python: eigenständige EXE

Wer das Tool ohne Python-Installation weitergeben will, baut einmalig eine EXE:

1. `Setup.bat` ausführen (holt `c2patool.exe`).
2. `build_exe.bat` ausführen → erzeugt `dist\TekNerds C2PA.exe`.
3. Die EXE + Ordner `Lizenzen` weitergeben. (Beim ersten Start ggf.
   SmartScreen: *„Weitere Informationen" → „Trotzdem ausführen"*.)

---

## Die drei Tabs

| Tab | Funktion |
|-----|----------|
| **Signieren** | Datei + Urheber, Software, Version, Aktion (Erstellt/Bearbeitet), KI-Einsatz, optional Copyright/URL/eigenes Zertifikat |
| **Prüfen** | liest das Manifest: Titel, Urheber, Software, KI, Aktionen, Aussteller, Signaturzeit, Validierung |
| **Anleitung** | komplette Installation/Nutzung + Schaubild + Problemlösung + Lizenzen |

Der **Power-Knopf (⏻)** oben rechts beendet den Server.

---

## Gut zu wissen

- **.mov** wird von c2patool nur eingeschränkt unterstützt → **MP4** nehmen.
- **Audio:** nur **WAV, MP3, M4A** können ein C2PA-Manifest einbetten
  (AIFF/AAC/FLAC/OGG nicht). Das Tool warnt bei nicht unterstützten Audioformaten.
- Ohne eigenes Zertifikat = **Test-Zertifikat**: gültig signiert, aber
  *„Aussteller nicht auf der Vertrauensliste"* – das ist normal und **kein Fehler**.
- **`assertion.dataHash.mismatch`** beim Prüfen = Datei wurde nach dem Signieren
  verändert → echter Fehler.
- **Erstellt** = Originaldatei · **Bearbeitet** = aus vorhandenem Material verändert.

---

## Konfiguration

| Umgebungsvariable | Wirkung | Standard |
|-------------------|---------|----------|
| `C2PA_PORT` | Server-Port | `8731` |
| `C2PA_OUTPUT_DIR` | Ausgabeordner | `Dokumente\C2PA-signed` |

---

## Projektaufbau

```
c2patool-v0.26.67/
  c2pa_signer.py        Die App (Python-Standardbibliothek, keine pip-Pakete)
  Setup.bat             Lädt c2patool.exe herunter (optional – die App holt es sonst selbst)
  Start_C2PA_Tool.bat   Startet die App
  build_exe.bat         Baut optional eine eigenständige EXE
  TN_AppIcon.ico/.png   App-Icon
  Lizenzen/             LICENSE-APACHE, LICENSE-MIT, Hinweise-Rechte-c2patool.txt
  README.md
```

---

## Lizenzen & Rechte

Die Signatur-Engine **c2patool** (c2pa-rs) ist © **Adobe** und doppelt lizenziert
unter **Apache-2.0 ODER MIT** (Quelle: github.com/contentauth/c2pa-rs).
c2patool wird **unverändert** mitgeliefert; die TekNerds-Oberfläche ist davon
getrennt. Vollständige Lizenztexte im Ordner **`Lizenzen`**.

Für den eigenen Oberflächen-Code solltet ihr noch eine Lizenz festlegen
(z. B. MIT) – c2patool ist davon getrennt bereits korrekt abgedeckt.
