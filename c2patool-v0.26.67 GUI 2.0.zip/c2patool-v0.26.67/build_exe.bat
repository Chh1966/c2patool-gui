@echo off
chcp 65001 >nul
title TekNerds C2PA - EXE
cd /d "%~dp0"
echo ================================================================
echo   TekNerds C2PA  -  EXE bauen / build  (optional)
echo   Ergebnis / result:  dist\TekNerds C2PA.exe
echo ================================================================
echo.
if not exist "c2patool.exe" ( echo c2patool.exe fehlt / missing - Setup.bat zuerst / first. & echo. & pause & goto :eof )
set "PYEXE="
where py >nul 2>nul && set "PYEXE=py -3"
if "%PYEXE%"=="" ( where python >nul 2>nul && set "PYEXE=python" )
if "%PYEXE%"=="" ( echo Python 3 nicht gefunden / not found: https://www.python.org/downloads/ & echo. & pause & goto :eof )
echo [1/3] PyInstaller ...
%PYEXE% -m pip install --upgrade pyinstaller || ( echo FEHLER/ERROR & echo. & pause & goto :eof )
echo [2/3] Build ...
%PYEXE% -m PyInstaller --noconfirm --clean --onefile --noconsole ^
  --name "TekNerds C2PA" --icon "TN_AppIcon.ico" ^
  --add-binary "c2patool.exe;." --add-data "Licenses;Licenses" "c2pa_signer.py"
if not exist "dist\TekNerds C2PA.exe" ( echo FEHLER/ERROR: Build. & echo. & pause & goto :eof )
echo [3/3] Lizenzen / licenses ...
if not exist "dist\Licenses" xcopy /E /I /Y "Licenses" "dist\Licenses" >nul
echo.
echo FERTIG / DONE ->  dist\TekNerds C2PA.exe
echo.
pause
