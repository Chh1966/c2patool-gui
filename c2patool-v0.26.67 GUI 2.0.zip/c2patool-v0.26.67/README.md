# TekNerds C2PA – Windows 11 (DE / EN)

Local tool to **sign** and **verify** C2PA Content Credentials, with a
**DE/EN language switch** and **batch signing** (multiple files or a whole
folder). · Lokales Tool zum **Signieren** und **Prüfen** von C2PA Content
Credentials, mit **Sprachschalter DE/EN** und **Stapel-Signierung**
(mehrere Dateien oder ganze Ordner).

- **GUI idea / GUI-Idee:** TekNerds · Nils Voss & Christian Homburg
- **Base software / Basis-Software:** [c2patool](https://github.com/contentauth/c2pa-rs) (C2PA) · © Adobe · Apache-2.0 / MIT
- Base framework created with Claude (Anthropic)

Runs entirely locally (127.0.0.1), opens in your browser, uploads nothing. ·
Läuft komplett lokal (127.0.0.1), öffnet im Browser, lädt nichts hoch.

---

## English

### Quick start
1. Double-click **`Setup.bat`** (downloads `c2patool.exe`; the app also fetches it on first start if missing).
2. Double-click **`Start_C2PA_Tool.bat`** – the browser opens.
3. Switch language top centre (**DE | EN**).
4. **Sign** tab: drop **files or a folder** (or use the buttons), fill in the fields (they apply to the whole batch), then **Apply seal**.

Signed files go to **`Documents\C2PA-signed`** (folder structure preserved).
Unsupported audio (AIFF/AAC/FLAC/OGG) is skipped with a note; only WAV/MP3/M4A embed C2PA. Use **MP4** instead of MOV.

### Without Python: standalone EXE
Run `Setup.bat`, then `build_exe.bat` → `dist\TekNerds C2PA.exe` (+ `Licenses` folder).

---

## Deutsch

### Schnellstart
1. **`Setup.bat`** doppelklicken (lädt `c2patool.exe`; die App holt es sonst beim ersten Start selbst).
2. **`Start_C2PA_Tool.bat`** doppelklicken – der Browser öffnet sich.
3. Sprache oben in der Mitte umschalten (**DE | EN**).
4. Reiter **Signieren**: **Dateien oder einen Ordner** ablegen (oder Knöpfe nutzen), Felder ausfüllen (gelten für den ganzen Stapel), dann **Siegel anbringen**.

Signierte Dateien landen in **`Dokumente\C2PA-signed`** (Ordnerstruktur bleibt erhalten).
Nicht einbettbares Audio (AIFF/AAC/FLAC/OGG) wird mit Hinweis übersprungen; nur WAV/MP3/M4A betten C2PA ein. Statt MOV bitte **MP4**.

### Ohne Python: eigenständige EXE
`Setup.bat`, dann `build_exe.bat` → `dist\TekNerds C2PA.exe` (+ Ordner `Licenses`).

---

## Configuration / Konfiguration
| Env | Effect / Wirkung | Default |
|-----|------------------|---------|
| `C2PA_PORT` | server port / Port | `8731` |
| `C2PA_OUTPUT_DIR` | output / Ausgabe | `Documents\C2PA-signed` |

## Layout
```
c2patool-v0.26.67/
  c2pa_signer.py        App (Python stdlib only)
  Setup.bat  Start_C2PA_Tool.bat  build_exe.bat
  TN_AppIcon.ico / .png
  Licenses/             LICENSE-APACHE, LICENSE-MIT, Notices-Rights-c2patool.txt
  README.md
```

## Licenses / Lizenzen
c2patool (c2pa-rs) © Adobe, dual licensed Apache-2.0 OR MIT, bundled unchanged.
Full texts in the `Licenses` folder. For your own GUI code, pick a license (e.g. MIT).
