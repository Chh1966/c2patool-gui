#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# =====================================================================
#  TekNerds C2PA  -  Sign & Verify C2PA Content Credentials
#  Windows 11  -  bilingual (DE/EN) + batch (multiple files / folders)
#
#  GUI idea:        TekNerds  -  Nils Voss & Christian Homburg
#  Base software:   c2patool (c2pa-rs)  -  (c) Adobe  -  Apache-2.0 / MIT
#  Base framework created with Claude (Anthropic)
#
#  Pure Python standard library - no pip packages required.
# =====================================================================

import os
import sys
import re
import io
import json
import time
import html
import shutil
import socket
import tempfile
import subprocess
import threading
import zipfile
import tarfile
import webbrowser
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

APP_NAME = "TekNerds C2PA"
VERSION  = "Build 2.0 (Windows)"

def _int_env(name, default):
    try:
        return int(os.environ.get(name, "").strip())
    except (ValueError, AttributeError):
        return default

PORT = _int_env("C2PA_PORT", 8731)
HOST = "127.0.0.1"

def _documents_dir():
    home = os.path.expanduser("~")
    docs = os.path.join(home, "Documents")
    if not os.path.isdir(docs):
        alt = os.path.join(home, "Dokumente")
        docs = alt if os.path.isdir(alt) else home
    return docs

OUTPUT_DIR = os.environ.get("C2PA_OUTPUT_DIR") or os.path.join(_documents_dir(), "C2PA-signed")

# ---------------------------------------------------------------------
# locate c2patool (Windows: c2patool.exe)
# ---------------------------------------------------------------------
def _app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def _data_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.join(
        os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "TekNerds-C2PA")

def find_c2patool():
    names = ("c2patool.exe", "c2patool")
    base = _app_dir()
    direct_dirs = [base, _data_dir()]
    mei = getattr(sys, "_MEIPASS", None)
    if mei:
        direct_dirs.append(mei)
    cwd = os.getcwd()
    if cwd not in direct_dirs:
        direct_dirs.append(cwd)
    for d in list(direct_dirs):
        for sub in ("bin", "_internal", os.path.join("_internal", "bin")):
            direct_dirs.append(os.path.join(d, sub))
    for d in direct_dirs:
        for n in names:
            p = os.path.join(d, n)
            if os.path.isfile(p):
                return p
    for root_dir in (base, _data_dir()):
        try:
            for root, _dirs, files in os.walk(root_dir):
                for n in names:
                    if n in files:
                        return os.path.join(root, n)
        except Exception:
            pass
    for n in names:
        found = shutil.which(n)
        if found:
            return found
    return None

C2PATOOL_VERSION = "v0.26.67"

def _platform_asset():
    if os.name == "nt":
        return "x86_64-pc-windows-msvc.zip", True
    if sys.platform == "darwin":
        return "universal-apple-darwin.zip", True
    return "x86_64-unknown-linux-gnu.tar.gz", False

def _github_latest_asset_url(suffix):
    api = "https://api.github.com/repos/contentauth/c2pa-rs/releases?per_page=60"
    req = urllib.request.Request(api, headers={"User-Agent": "TekNerds-C2PA"})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.loads(r.read().decode("utf-8"))
    for rel in data:
        if not str(rel.get("tag_name", "")).startswith("c2patool-"):
            continue
        for a in rel.get("assets", []):
            if str(a.get("name", "")).endswith(suffix):
                return a.get("browser_download_url")
    return None

def _download(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent": "TekNerds-C2PA"})
    with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f)

def _extract_binary(archive_path, is_zip, dest_dir):
    names = ("c2patool.exe", "c2patool")
    tmp = tempfile.mkdtemp(prefix="c2pa_dl_")
    try:
        if is_zip:
            with zipfile.ZipFile(archive_path) as z:
                z.extractall(tmp)
        else:
            with tarfile.open(archive_path) as t:
                t.extractall(tmp)
        for root, _dirs, files in os.walk(tmp):
            for n in names:
                if n in files:
                    os.makedirs(dest_dir, exist_ok=True)
                    target = os.path.join(dest_dir, n)
                    shutil.copyfile(os.path.join(root, n), target)
                    if os.name != "nt":
                        os.chmod(target, 0o755)
                    return target
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return None

def autofetch_c2patool():
    suffix, is_zip = _platform_asset()
    pinned = ("https://github.com/contentauth/c2pa-rs/releases/download/"
              "c2patool-%s/c2patool-%s-%s" % (C2PATOOL_VERSION,
                                              C2PATOOL_VERSION, suffix))
    archive = os.path.join(tempfile.gettempdir(),
                           "c2patool_dl" + (".zip" if is_zip else ".tar.gz"))
    try:
        try:
            _download(pinned, archive)
        except Exception:
            url = _github_latest_asset_url(suffix)
            if not url:
                return None
            _download(url, archive)
    except Exception as e:
        print("   Download failed:", e)
        return None
    for dest in (_app_dir(), _data_dir()):
        try:
            path = _extract_binary(archive, is_zip, dest)
            if path:
                try:
                    os.remove(archive)
                except OSError:
                    pass
                return path
        except (PermissionError, OSError):
            continue
    return None

C2PATOOL = find_c2patool()


# ---------------------------------------------------------------------
# IPTC digitalSourceType (AI use)
# ---------------------------------------------------------------------
IPTC = "http://cv.iptc.org/newscodes/digitalsourcetype/"
AI_SOURCE = {
    "keine":        None,
    "teilweise":    IPTC + "compositeWithTrainedAlgorithmicMedia",
    "vollstaendig": IPTC + "trainedAlgorithmicMedia",
}

# Audio formats that c2patool can embed vs. those it cannot
AUDIO_OK  = {".mp3", ".wav", ".m4a"}
AUDIO_BAD = {".aac", ".aiff", ".aif", ".flac", ".ogg", ".alac"}


def build_manifest(fields, title):
    author    = (fields.get("author") or "").strip()
    software  = (fields.get("software") or "DaVinci Resolve").strip()
    swversion = (fields.get("version") or "").strip()
    action    = (fields.get("action") or "created").strip()
    ai        = (fields.get("ai") or "keine").strip()
    copyright_= (fields.get("copyright") or "").strip()
    url       = (fields.get("url") or "").strip()

    software_full = software + (" " + swversion if swversion else "")
    c2pa_action = "c2pa.edited" if action == "edited" else "c2pa.created"

    act = {"action": c2pa_action, "softwareAgent": {"name": software_full or software}}
    src = AI_SOURCE.get(ai)
    if src:
        act["digitalSourceType"] = src

    manifest = {
        "alg": "es256",
        "title": title,
        "claim_generator_info": [{"name": "TekNerds C2PA", "version": "2.0"}],
        "assertions": [{"label": "c2pa.actions.v2", "data": {"actions": [act]}}],
    }
    cw = {"@context": "https://schema.org", "@type": "CreativeWork"}
    has_cw = False
    if author:
        cw["author"] = [{"@type": "Person", "name": author}]; has_cw = True
    if copyright_:
        cw["copyrightNotice"] = copyright_; has_cw = True
    if url:
        cw["url"] = url; has_cw = True
    if has_cw:
        manifest["assertions"].append(
            {"label": "stds.schema-org.CreativeWork", "data": cw})
    return manifest


def sign_file(src_path, out_path, fields):
    if not C2PATOOL:
        return False, "no-c2patool"
    title = os.path.basename(src_path)
    manifest = build_manifest(fields, title)
    tmpdir = tempfile.mkdtemp(prefix="c2pa_")
    man_path = os.path.join(tmpdir, "manifest.json")
    env = dict(os.environ)
    cert = (fields.get("cert") or "").strip()
    key  = (fields.get("key") or "").strip()
    if cert and key and os.path.isfile(cert) and os.path.isfile(key):
        env["C2PA_SIGN_CERT"] = cert
        env["C2PA_PRIVATE_KEY"] = key
    try:
        with open(man_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
        cmd = [C2PATOOL, src_path, "-m", man_path, "-o", out_path, "--force"]
        p = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=300)
        if p.returncode == 0 and os.path.isfile(out_path):
            return True, ""
        return False, (p.stderr or p.stdout or "error").strip()
    except subprocess.TimeoutExpired:
        return False, "timeout"
    except Exception as e:
        return False, str(e)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def verify_file(src_path):
    if not C2PATOOL:
        return {"status": "error", "message": "no-c2patool"}
    try:
        p = subprocess.run([C2PATOOL, src_path], capture_output=True,
                           text=True, timeout=120)
    except subprocess.TimeoutExpired:
        return {"status": "error", "message": "timeout"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
    out = (p.stdout or "").strip()
    err = (p.stderr or "").strip()
    if not out or "No claim found" in out or "no claim" in out.lower() or "No manifest" in out:
        return {"status": "none"}
    try:
        data = json.loads(out)
    except json.JSONDecodeError:
        low = (out + " " + err).lower()
        if "no claim" in low or "not found" in low:
            return {"status": "none"}
        return {"status": "error", "message": (err or out)[:500]}
    return parse_manifest_report(data)


def _first(lst):
    return lst[0] if isinstance(lst, list) and lst else None


def parse_manifest_report(data):
    result = {"status": "ok", "title": "", "author": "", "software": "",
              "ai": "", "actions": [], "issuer": "", "time": "",
              "validation": [], "real_error": False}
    active = data.get("active_manifest")
    manifests = data.get("manifests", {})
    man = manifests.get(active) if active else None
    if not man and manifests:
        man = next(iter(manifests.values()))
    if not man:
        return {"status": "none"}
    result["title"] = man.get("title", "") or ""
    cg = man.get("claim_generator_info") or []
    if cg and isinstance(cg, list):
        nm = cg[0].get("name", ""); ver = cg[0].get("version", "")
        result["software"] = (nm + (" " + ver if ver else "")).strip()
    if not result["software"]:
        result["software"] = man.get("claim_generator", "") or ""
    sig = man.get("signature_info", {}) or {}
    result["issuer"] = sig.get("issuer", "") or sig.get("common_name", "") or ""
    result["time"]   = sig.get("time", "") or ""
    for a in man.get("assertions", []):
        label = a.get("label", "")
        adata = a.get("data", {}) or {}
        if label.startswith("c2pa.actions"):
            for act in adata.get("actions", []):
                name = act.get("action", "")
                sa = act.get("softwareAgent", "")
                if isinstance(sa, dict):
                    sa = sa.get("name", "")
                dst = act.get("digitalSourceType", "")
                txt = name + (" \u00b7 " + sa if sa else "")
                result["actions"].append(txt)
                if dst:
                    if "trainedAlgorithmicMedia" in dst and "composite" not in dst:
                        result["ai"] = "vollstaendig"
                    elif "composite" in dst:
                        result["ai"] = "teilweise"
        elif label.startswith("stds.schema-org.CreativeWork"):
            au = adata.get("author")
            a0 = _first(au) if isinstance(au, list) else au
            if isinstance(a0, dict):
                result["author"] = a0.get("name", "") or ""
    vstatus = man.get("validation_status") or data.get("validation_status") or []
    benign = {"signingCredential.untrusted"}
    real = []
    for v in vstatus:
        code = v.get("code", "") if isinstance(v, dict) else str(v)
        if code in benign:
            continue
        real.append(code)
    result["validation"] = real
    result["real_error"] = len(real) > 0
    return result


# ---------------------------------------------------------------------
# multipart/form-data parser (binary-safe, MULTIPLE files supported)
# ---------------------------------------------------------------------
def parse_multipart(body, boundary):
    """Returns (fields:dict, files:list[(fieldname, filename, bytes)])."""
    fields, files = {}, []
    delim = b"--" + boundary
    for part in body.split(delim):
        if not part or part in (b"--\r\n", b"--", b"\r\n"):
            continue
        if part.startswith(b"\r\n"):
            part = part[2:]
        if part.endswith(b"\r\n"):
            part = part[:-2]
        head_end = part.find(b"\r\n\r\n")
        if head_end == -1:
            continue
        raw_head = part[:head_end].decode("utf-8", "replace")
        content = part[head_end + 4:]
        m_name = re.search(r'name="([^"]*)"', raw_head)
        if not m_name:
            continue
        name = m_name.group(1)
        m_file = re.search(r'filename="([^"]*)"', raw_head)
        if m_file:
            files.append((name, m_file.group(1), content))
        else:
            fields[name] = content.decode("utf-8", "replace")
    return fields, files


def safe_name(name):
    name = os.path.basename(name or "")
    name = re.sub(r'[^A-Za-z0-9._ \-()]', "_", name)
    return name or "file"

def safe_relpath(rel):
    """Sanitize a relative path (folder upload) - no .. or absolute parts."""
    rel = (rel or "").replace("\\", "/")
    parts = [re.sub(r'[^A-Za-z0-9._ \-()]', "_", p) for p in rel.split("/")
             if p and p not in (".", "..")]
    return os.path.join(*parts) if parts else ""

def ext_of(name):
    return os.path.splitext(name or "")[1].lower()


# ---------------------------------------------------------------------
# i18n strings (German / English) - injected into the page as JSON
# ---------------------------------------------------------------------
I18N = {
  "de": {
    "subtitle": "C2PA \u00b7 Signieren & Pr\u00fcfen \u00b7 " + VERSION,
    "tab_sign": "SIGNIEREN", "tab_verify": "PR\u00dcFEN", "tab_guide": "ANLEITUNG",
    "drop_sign": "Dateien oder Ordner hierher ziehen<br>oder unten ausw\u00e4hlen",
    "pick_files": "Dateien w\u00e4hlen", "pick_folder": "Ordner w\u00e4hlen",
    "clear": "Liste leeren",
    "files_count": "Datei(en) ausgew\u00e4hlt",
    "author": "Urheber", "software": "Software", "version_opt": "Version (optional)",
    "ai_use": "KI-Einsatz", "action": "Aktion", "created": "Erstellt", "edited": "Bearbeitet",
    "action_hint": "Erstellt = Originaldatei \u00b7 Bearbeitet = aus vorhandenem Material ver\u00e4ndert.",
    "ai_none": "Keine", "ai_partial": "Teilweise KI", "ai_full": "Vollst\u00e4ndig KI-generiert",
    "more": "Weitere Angaben (Copyright, URL, eigenes Zertifikat)",
    "copyright": "Copyright", "url": "URL",
    "cert": "Zertifikat (.pem, Pfad)", "key": "Schl\u00fcssel (.pem, Pfad)",
    "cert_hint": "Ohne eigenes Zertifikat wird das Test-Zertifikat von c2patool verwendet (g\u00fcltig signiert, aber \u201eAussteller nicht auf der Vertrauensliste\u201c).",
    "btn_seal": "SIEGEL ANBRINGEN", "ver_phint": "z. B. 19.1",
    "drop_verify": "Datei zum Pr\u00fcfen hierher ziehen<br>oder klicken", "btn_verify": "PR\u00dcFEN",
    "sealing": "SIGNIERE", "verifying": "PR\u00dcFE",
    "sealed": "GESIEGELT", "error": "FEHLER", "unknown": "Unbekannt",
    "file": "Datei", "folder": "Ordner", "open_folder": "Ordner \u00f6ffnen", "download": "Download",
    "saved_hint": "Signierte Dateien liegen immer automatisch im Ordner.",
    "summary": "%s signiert \u00b7 %s \u00fcbersprungen \u00b7 %s fehlgeschlagen",
    "skip_audio": "\u00fcbersprungen \u2013 Audioformat nicht einbettbar (WAV/MP3/M4A nehmen)",
    "valid": "G\u00dcLTIG SIGNIERT", "failed": "VALIDIERUNG FEHLGESCHLAGEN",
    "title": "Titel", "issuer": "Aussteller", "signed_on": "Signiert am",
    "actions_label": "Aktionen", "ai": "KI",
    "no_creds": "KEINE CREDENTIALS", "no_creds_text": "Diese Datei enth\u00e4lt keine C2PA Content Credentials.",
    "trust_hint": "Aussteller-Vertrauen (Trust-Liste) wird lokal nicht gepr\u00fcft. Test-Zertifikat = \u201eAussteller nicht auf der Vertrauensliste\u201c ist normal. Voller Trust-Check: verify.contentauthenticity.org",
    "audio_warn": "Hinweis: Audioformate au\u00dfer WAV/MP3/M4A werden \u00fcbersprungen (nicht einbettbar).",
    "confirm_quit": "Server beenden? Die App wird geschlossen.",
    "overlay_quit": "Server beendet \u2013 du kannst dieses Fenster jetzt schlie\u00dfen.",
    "power_title": "Server beenden", "status_title": "c2patool-Status",
    "foot_gui": "GUI-Idee:", "foot_base": "Basis-Software:",
    "foot_lic": "c2patool \u00a9 Adobe \u00b7 Apache-2.0 / MIT \u00b7 Lizenztexte: Anleitung & Ordner \u201eLicenses\u201c"
  },
  "en": {
    "subtitle": "C2PA \u00b7 Sign & Verify \u00b7 " + VERSION,
    "tab_sign": "SIGN", "tab_verify": "VERIFY", "tab_guide": "GUIDE",
    "drop_sign": "Drop files or a folder here<br>or choose below",
    "pick_files": "Choose files", "pick_folder": "Choose folder",
    "clear": "Clear list",
    "files_count": "file(s) selected",
    "author": "Author", "software": "Software", "version_opt": "Version (optional)",
    "ai_use": "AI use", "action": "Action", "created": "Created", "edited": "Edited",
    "action_hint": "Created = original file \u00b7 Edited = changed from existing material.",
    "ai_none": "None", "ai_partial": "Partial AI", "ai_full": "Fully AI-generated",
    "more": "More details (copyright, URL, own certificate)",
    "copyright": "Copyright", "url": "URL",
    "cert": "Certificate (.pem, path)", "key": "Key (.pem, path)",
    "cert_hint": "Without your own certificate, c2patool's test certificate is used (validly signed, but \u201cissuer not on the trust list\u201d).",
    "btn_seal": "APPLY SEAL", "ver_phint": "e.g. 19.1",
    "drop_verify": "Drop a file to verify here<br>or click", "btn_verify": "VERIFY",
    "sealing": "SIGNING", "verifying": "VERIFYING",
    "sealed": "SEALED", "error": "ERROR", "unknown": "Unknown",
    "file": "File", "folder": "Folder", "open_folder": "Open folder", "download": "Download",
    "saved_hint": "Signed files are always saved automatically in the folder.",
    "summary": "%s signed \u00b7 %s skipped \u00b7 %s failed",
    "skip_audio": "skipped \u2013 audio format cannot embed C2PA (use WAV/MP3/M4A)",
    "valid": "VALIDLY SIGNED", "failed": "VALIDATION FAILED",
    "title": "Title", "issuer": "Issuer", "signed_on": "Signed on",
    "actions_label": "Actions", "ai": "AI",
    "no_creds": "NO CREDENTIALS", "no_creds_text": "This file has no C2PA Content Credentials.",
    "trust_hint": "Issuer trust (trust list) is not checked locally. Test certificate = \u201cissuer not on the trust list\u201d is normal. Full trust check: verify.contentauthenticity.org",
    "audio_warn": "Note: audio formats other than WAV/MP3/M4A are skipped (cannot embed).",
    "confirm_quit": "Stop server? The app will close.",
    "overlay_quit": "Server stopped \u2013 you can close this window now.",
    "power_title": "Stop server", "status_title": "c2patool status",
    "foot_gui": "GUI idea:", "foot_base": "Base software:",
    "foot_lic": "c2patool \u00a9 Adobe \u00b7 Apache-2.0 / MIT \u00b7 license texts: Guide & \u201cLicenses\u201d folder"
  }
}

TN_LOGO_SVG = '''<svg width="46" height="46" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-label="TekNerds">
<rect x="2" y="2" width="96" height="96" rx="20" ry="20" fill="#000" stroke="#2a2a2a" stroke-width="1.5"/>
<text x="50" y="52" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-weight="800" font-size="40" fill="#fff" letter-spacing="-1">TN</text>
<text x="50" y="78" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-weight="600" font-size="13" fill="#bdbdbd" letter-spacing="0.5">TekNerds</text>
</svg>'''

def page_html():
    return PAGE_TEMPLATE.replace("{TN_LOGO}", TN_LOGO_SVG)\
                        .replace("{I18N_JSON}", json.dumps(I18N, ensure_ascii=False))\
                        .replace("{TOOLSTATE}", "on" if C2PATOOL else "off")


PAGE_TEMPLATE = r"""<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Cache-Control" content="no-store">
<title>TekNerds C2PA</title>
<style>
  :root{
    --yellow:#C8C800; --cyan:#17B8C9; --green:#1FAF3A;
    --magenta:#C21FC2; --red:#C8161D; --blue:#1E2FC4;
    --panel:#0c0c0c; --panel2:#141414; --bay:#1b1b1b;
    --line:#2a2a2a; --txt:#e8e8e8; --muted:#9a9a9a; --accent:#17B8C9;
  }
  *{box-sizing:border-box}
  html,body{margin:0;padding:0}
  body{font-family:"SF Mono",Menlo,Consolas,"DejaVu Sans Mono",monospace;
    color:var(--txt); min-height:100vh;
    background:linear-gradient(rgba(0,0,0,.04) 1px,transparent 1px) 0 0/22px 22px,
      linear-gradient(90deg,rgba(0,0,0,.04) 1px,transparent 1px) 0 0/22px 22px,#b9b9b9;
    display:flex; justify-content:center; padding:26px 14px 40px;}
  .console{width:100%; max-width:780px; background:var(--panel);
    border:1px solid var(--line); border-radius:14px; overflow:hidden;
    box-shadow:0 18px 50px rgba(0,0,0,.45);}
  header{display:flex; align-items:center; gap:13px; padding:14px 16px;
    background:linear-gradient(#181818,#101010); border-bottom:1px solid var(--line);}
  header .logo{flex:0 0 auto; display:flex}
  header .titles{flex:1 1 auto; min-width:0}
  header .titles .t1{font-weight:700; font-size:15px; letter-spacing:.5px}
  header .titles .t2{font-size:11px; color:var(--muted); margin-top:2px}
  .lang{display:flex; border:1px solid var(--line); border-radius:6px; overflow:hidden}
  .lang button{background:#161616; border:0; color:var(--muted); font-family:inherit;
    font-size:11px; padding:5px 9px; cursor:pointer}
  .lang button.on{background:var(--accent); color:#001; font-weight:700}
  header .led{width:10px;height:10px;border-radius:50%;box-shadow:0 0 7px currentColor}
  header .led.on{color:#27d558;background:#27d558}
  header .led.off{color:#d33;background:#d33}
  .power{flex:0 0 auto; width:34px;height:34px;border-radius:50%;
    border:1px solid var(--line); background:#161616; color:#bbb; cursor:pointer;
    font-size:16px; line-height:1; display:flex; align-items:center; justify-content:center;}
  .power:hover{color:#fff; border-color:#444; background:#1d1d1d}
  .bars{display:flex; height:9px}
  .bars span{flex:1}
  .bars .b1{background:var(--yellow)} .bars .b2{background:var(--cyan)}
  .bars .b3{background:var(--green)}  .bars .b4{background:var(--magenta)}
  .bars .b5{background:var(--red)}    .bars .b6{background:var(--blue)}
  .tabs{display:flex; background:var(--panel2); border-bottom:1px solid var(--line)}
  .tabs button{flex:1; background:none; border:0; color:var(--muted); padding:12px 8px;
    font-family:inherit; font-size:12.5px; letter-spacing:.6px; cursor:pointer;
    border-bottom:2px solid transparent;}
  .tabs button.active{color:#fff; border-bottom-color:var(--accent); background:#101010}
  .tabs button:hover{color:#ddd}
  .body{padding:18px 18px 8px}
  .pane{display:none} .pane.active{display:block}
  .drop{border:1.5px dashed #3a3a3a; border-radius:10px; background:#0e0e0e;
    padding:22px 16px; text-align:center; color:var(--muted); cursor:pointer; transition:.15s;}
  .drop:hover,.drop.hot{border-color:var(--accent); color:#ddd; background:#0f1414}
  .drop .fn{color:#fff; word-break:break-all}
  .pickrow{display:flex; gap:9px; margin-top:10px; flex-wrap:wrap}
  .pickrow button{font-family:inherit; font-size:12px; cursor:pointer; padding:8px 12px;
    border-radius:6px; border:1px solid var(--line); background:#161616; color:#ddd}
  .pickrow button:hover{border-color:#444; color:#fff}
  .filelist{margin-top:10px; max-height:150px; overflow:auto; border:1px solid var(--line);
    border-radius:7px; background:#0e0e0e; display:none}
  .filelist.show{display:block}
  .filelist .it{padding:6px 10px; font-size:12px; color:#cfcfcf; border-bottom:1px solid #161616;
    display:flex; justify-content:space-between; gap:8px}
  .filelist .it:last-child{border-bottom:0}
  .filelist .it .nm{word-break:break-all}
  .filelist .it .sz{color:#6f6f6f; flex:0 0 auto}
  label{display:block; font-size:11px; color:var(--muted); margin:12px 0 4px;
    letter-spacing:.5px; text-transform:uppercase}
  input[type=text],select{width:100%; background:var(--bay); border:1px solid var(--line);
    color:var(--txt); border-radius:7px; padding:9px 10px; font-family:inherit; font-size:13px;}
  input::placeholder{color:#666}
  input:focus,select:focus{outline:none; border-color:var(--accent)}
  .row{display:flex; gap:12px} .row>div{flex:1}
  .seg{display:flex; border:1px solid var(--line); border-radius:7px; overflow:hidden}
  .seg button{flex:1; background:var(--bay); border:0; color:var(--muted); padding:9px;
    font-family:inherit; font-size:12.5px; cursor:pointer}
  .seg button.on{background:var(--accent); color:#001}
  .hint{font-size:11px; color:#7d7d7d; margin-top:6px; line-height:1.5}
  details{margin-top:14px; border:1px solid var(--line); border-radius:7px; background:#0e0e0e}
  details summary{cursor:pointer; padding:9px 11px; font-size:12px; color:var(--muted)}
  .seal{width:100%; margin-top:18px; padding:14px; border:0; border-radius:9px;
    background:linear-gradient(#1c8fa0,#0f6f7d); color:#fff; font-family:inherit;
    font-size:15px; font-weight:700; letter-spacing:2px; cursor:pointer;
    box-shadow:0 0 0 1px #17b8c9 inset, 0 6px 16px rgba(23,184,201,.25)}
  .seal:hover{filter:brightness(1.08)}
  .seal:disabled{opacity:.5; cursor:default}
  .result{margin-top:16px; border-radius:9px; padding:14px 15px; display:none;
    font-size:13px; line-height:1.6}
  .result.show{display:block}
  .result.good{background:#0e2014; border:1px solid #1f6f3a}
  .result.bad{background:#23110f; border:1px solid #7a2420}
  .result.info{background:#101a1d; border:1px solid #1f5f6a}
  .result h4{margin:0 0 8px; font-size:13px; letter-spacing:1px}
  .result .k{color:var(--muted); display:inline-block; min-width:96px}
  .result .v{color:#fff}
  .result .acts{color:#cfcfcf}
  .blist .bi{display:flex; gap:8px; padding:4px 0; font-size:12.5px; border-top:1px solid #ffffff14}
  .blist .bi:first-child{border-top:0}
  .blist .ic{flex:0 0 auto; width:16px}
  .blist .ok{color:#46d473} .blist .sk{color:#d8a13a} .blist .er{color:#e7726a}
  .blist .nm{word-break:break-all}
  .btnrow{margin-top:12px; display:flex; gap:9px; flex-wrap:wrap}
  .btnrow a,.btnrow button{font-family:inherit; font-size:12px; cursor:pointer;
    text-decoration:none; padding:8px 12px; border-radius:6px; border:1px solid var(--line);
    background:#161616; color:#ddd}
  .btnrow a:hover,.btnrow button:hover{border-color:#444; color:#fff}
  .guide h3{font-size:13px; color:var(--accent); letter-spacing:1px; margin:18px 0 6px}
  .guide h3:first-child{margin-top:4px}
  .guide p,.guide li{font-size:12.5px; color:#cfcfcf; line-height:1.65}
  .guide ul{margin:4px 0 4px 18px; padding:0}
  .guide code{background:#1b1b1b; padding:1px 6px; border-radius:4px; color:#9fe0e8; font-size:12px}
  .schema{width:100%; border:1px solid var(--line); border-radius:9px; margin:6px 0 4px; background:#0e0e0e}
  footer{padding:13px 16px; border-top:1px solid var(--line); background:var(--panel2);
    color:#6f6f6f; font-size:10.5px; line-height:1.7}
  footer .v{color:#9a9a9a}
  .overlay{position:fixed; inset:0; background:#0a0a0a; display:none; align-items:center;
    justify-content:center; color:#ddd; font-size:15px; text-align:center; padding:30px}
  .overlay.show{display:flex}
</style>
</head>
<body>
<div class="console">
  <header>
    <div class="logo">{TN_LOGO}</div>
    <div class="titles">
      <div class="t1">TekNerds</div>
      <div class="t2" data-i18n="subtitle"></div>
    </div>
    <div class="lang">
      <button id="langDe" data-lang="de">DE</button>
      <button id="langEn" data-lang="en">EN</button>
    </div>
    <div class="led {TOOLSTATE}" id="led" data-i18n-title="status_title"></div>
    <button class="power" id="power" data-i18n-title="power_title">&#9211;</button>
  </header>
  <div class="bars"><span class="b1"></span><span class="b2"></span><span class="b3"></span><span class="b4"></span><span class="b5"></span><span class="b6"></span></div>

  <div class="tabs">
    <button data-tab="sign" class="active" data-i18n="tab_sign"></button>
    <button data-tab="verify" data-i18n="tab_verify"></button>
    <button data-tab="guide" data-i18n="tab_guide"></button>
  </div>

  <div class="body">
    <!-- SIGN (batch) -->
    <div class="pane active" id="pane-sign">
      <div class="drop" id="dropS"><div id="dropStxt" data-i18n-html="drop_sign"></div></div>
      <input type="file" id="fileS" multiple style="display:none">
      <input type="file" id="folderS" webkitdirectory directory style="display:none">
      <div class="pickrow">
        <button id="btnFiles" data-i18n="pick_files"></button>
        <button id="btnFolder" data-i18n="pick_folder"></button>
        <button id="btnClear" data-i18n="clear"></button>
      </div>
      <div class="filelist" id="flist"></div>
      <div id="audioWarn" class="hint" style="display:none;color:#d8a13a"></div>

      <div class="row">
        <div><label data-i18n="author"></label>
          <input type="text" id="author" placeholder="Voss &amp; Homburg"></div>
        <div><label data-i18n="software"></label>
          <input type="text" id="software" value="DaVinci Resolve"></div>
      </div>
      <div class="row">
        <div><label data-i18n="version_opt"></label>
          <input type="text" id="version" data-i18n-ph="ver_phint"></div>
        <div><label data-i18n="ai_use"></label>
          <select id="ai">
            <option value="keine" data-i18n="ai_none"></option>
            <option value="teilweise" data-i18n="ai_partial"></option>
            <option value="vollstaendig" data-i18n="ai_full"></option>
          </select></div>
      </div>
      <label data-i18n="action"></label>
      <div class="seg" id="segAction">
        <button data-a="created" class="on" data-i18n="created"></button>
        <button data-a="edited" data-i18n="edited"></button>
      </div>
      <div class="hint" data-i18n="action_hint"></div>

      <details>
        <summary data-i18n="more"></summary>
        <div style="padding:6px 11px 12px">
          <div class="row">
            <div><label data-i18n="copyright"></label>
              <input type="text" id="copyright" placeholder="&copy; 2026 Voss &amp; Homburg"></div>
            <div><label data-i18n="url"></label>
              <input type="text" id="url" placeholder="https://..."></div>
          </div>
          <div class="row">
            <div><label data-i18n="cert"></label>
              <input type="text" id="cert" placeholder="C:\\path\\cert.pem"></div>
            <div><label data-i18n="key"></label>
              <input type="text" id="key" placeholder="C:\\path\\key.pem"></div>
          </div>
          <div class="hint" data-i18n="cert_hint"></div>
        </div>
      </details>

      <button class="seal" id="signBtn" disabled data-i18n="btn_seal"></button>
      <div class="result" id="resS"></div>
    </div>

    <!-- VERIFY -->
    <div class="pane" id="pane-verify">
      <div class="drop" id="dropV"><div id="dropVtxt" data-i18n-html="drop_verify"></div></div>
      <input type="file" id="fileV" style="display:none">
      <button class="seal" id="verifyBtn" disabled data-i18n="btn_verify"></button>
      <div class="result" id="resV"></div>
    </div>

    <!-- GUIDE -->
    <div class="pane guide" id="pane-guide"></div>
  </div>

  <footer>
    <div><span data-i18n="foot_gui"></span> <span class="v">TekNerds &middot; Nils Voss &amp; Christian Homburg</span> &middot; <span data-i18n="foot_base"></span> <span class="v">c2patool (C2PA)</span></div>
    <div data-i18n="foot_lic"></div>
  </footer>
</div>
<div class="overlay" id="overlay"></div>
<script>
const I18N = {I18N_JSON};
const AUDIO_BAD=["aac","aiff","aif","flac","ogg","alac"];
let LANG = localStorage.getItem('c2pa_lang') || 'de';
const $=s=>document.querySelector(s);
function t(k){ return (I18N[LANG]&&I18N[LANG][k])!==undefined ? I18N[LANG][k] : k; }
function esc(s){return (s+'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function ext(n){const p=(n||"").split('.');return p.length>1?p.pop().toLowerCase():"";}

let picked=[];           // {file, path}
let lastSign=null, lastVerify=null, fileV=null, action='created';

// ---------- i18n apply ----------
function applyLang(){
  document.querySelectorAll('[data-i18n]').forEach(e=>e.textContent=t(e.dataset.i18n));
  document.querySelectorAll('[data-i18n-html]').forEach(e=>e.innerHTML=t(e.dataset.i18nHtml));
  document.querySelectorAll('[data-i18n-ph]').forEach(e=>e.setAttribute('placeholder',t(e.dataset.i18nPh)));
  document.querySelectorAll('[data-i18n-title]').forEach(e=>e.setAttribute('title',t(e.dataset.i18nTitle)));
  $('#langDe').classList.toggle('on',LANG==='de');
  $('#langEn').classList.toggle('on',LANG==='en');
  document.documentElement.lang=LANG;
  updateSealBtn(); renderFileList(); loadGuide();
  if(lastSign) renderSign(); if(lastVerify) renderVerify();
}
function setLang(l){ LANG=l; localStorage.setItem('c2pa_lang',l); applyLang(); }
$('#langDe').onclick=()=>setLang('de');
$('#langEn').onclick=()=>setLang('en');

// ---------- tabs ----------
document.querySelectorAll('.tabs button').forEach(b=>{
  b.onclick=()=>{
    document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.pane').forEach(x=>x.classList.remove('active'));
    b.classList.add('active'); $('#pane-'+b.dataset.tab).classList.add('active');
  };
});

// ---------- action toggle ----------
document.querySelectorAll('#segAction button').forEach(b=>{
  b.onclick=()=>{
    document.querySelectorAll('#segAction button').forEach(x=>x.classList.remove('on'));
    b.classList.add('on'); action=b.dataset.a;
  };
});

// ---------- file collection ----------
function keyOf(p){ return p.path.toLowerCase(); }
function addFiles(arr){
  const seen=new Set(picked.map(keyOf));
  arr.forEach(o=>{ if(!seen.has(keyOf(o))){ picked.push(o); seen.add(keyOf(o)); } });
  renderFileList(); updateSealBtn(); updateAudioWarn();
}
function filesFromInput(input, asFolder){
  const arr=[];
  for(const f of input.files){ arr.push({file:f, path:(asFolder&&f.webkitRelativePath)?f.webkitRelativePath:f.name}); }
  return arr;
}
$('#btnFiles').onclick=()=>$('#fileS').click();
$('#btnFolder').onclick=()=>$('#folderS').click();
$('#btnClear').onclick=()=>{ picked=[]; renderFileList(); updateSealBtn(); updateAudioWarn(); };
$('#fileS').onchange=()=>{ addFiles(filesFromInput($('#fileS'),false)); $('#fileS').value=''; };
$('#folderS').onchange=()=>{ addFiles(filesFromInput($('#folderS'),true)); $('#folderS').value=''; };

// drag & drop (files and folders)
const dropS=$('#dropS');
['dragover','dragenter'].forEach(e=>dropS.addEventListener(e,ev=>{ev.preventDefault();dropS.classList.add('hot');}));
['dragleave'].forEach(e=>dropS.addEventListener(e,ev=>{ev.preventDefault();dropS.classList.remove('hot');}));
dropS.onclick=()=>$('#fileS').click();
dropS.addEventListener('drop', async ev=>{
  ev.preventDefault(); dropS.classList.remove('hot');
  const items=ev.dataTransfer.items;
  if(items && items.length && items[0].webkitGetAsEntry){
    const collected=[];
    const entries=[];
    for(const it of items){ const en=it.webkitGetAsEntry&&it.webkitGetAsEntry(); if(en) entries.push(en); }
    for(const en of entries){ await walkEntry(en,"",collected); }
    addFiles(collected);
  } else {
    const arr=[]; for(const f of ev.dataTransfer.files) arr.push({file:f,path:f.name}); addFiles(arr);
  }
});
function walkEntry(entry, prefix, out){
  return new Promise(res=>{
    if(entry.isFile){
      entry.file(f=>{ out.push({file:f, path:(prefix?prefix+'/':'')+entry.name}); res(); }, ()=>res());
    } else if(entry.isDirectory){
      const rd=entry.createReader(); const all=[];
      const readBatch=()=>rd.readEntries(async ents=>{
        if(!ents.length){ for(const e of all){ await walkEntry(e, (prefix?prefix+'/':'')+entry.name, out); } res(); }
        else { all.push(...ents); readBatch(); }
      }, ()=>res());
      readBatch();
    } else res();
  });
}
function renderFileList(){
  const box=$('#flist');
  if(!picked.length){ box.classList.remove('show'); box.innerHTML=''; return; }
  box.classList.add('show');
  box.innerHTML=picked.map(o=>'<div class="it"><span class="nm">'+esc(o.path)+'</span><span class="sz">'+fmtSize(o.file.size)+'</span></div>').join('');
}
function fmtSize(n){ if(n<1024)return n+' B'; if(n<1048576)return (n/1024).toFixed(0)+' KB'; return (n/1048576).toFixed(1)+' MB'; }
function updateSealBtn(){
  const b=$('#signBtn');
  b.disabled = picked.length===0;
  b.textContent = t('btn_seal') + (picked.length?(' ('+picked.length+')'):'');
}
function updateAudioWarn(){
  const w=$('#audioWarn');
  const bad=picked.some(o=>AUDIO_BAD.includes(ext(o.path)));
  if(bad){ w.style.display='block'; w.textContent=t('audio_warn'); } else w.style.display='none';
}

// ---------- sign (batch) ----------
$('#signBtn').onclick=async()=>{
  if(!picked.length) return;
  const btn=$('#signBtn'); btn.disabled=true; const old=btn.textContent;
  btn.textContent=t('sealing')+' \u2026 (0/'+picked.length+')';
  const fd=new FormData();
  const paths=[];
  picked.forEach(o=>{ fd.append('file',o.file,o.file.name); paths.push(o.path); });
  fd.append('paths',JSON.stringify(paths));
  ['author','software','version','ai','copyright','url','cert','key'].forEach(id=>fd.append(id,$('#'+id).value));
  fd.append('action',action);
  try{
    const r=await fetch('/sign',{method:'POST',body:fd});
    lastSign=await r.json();
  }catch(e){ lastSign={error:e.message}; }
  renderSign();
  btn.disabled=false; updateSealBtn();
};
function renderSign(){
  const box=$('#resS'); const j=lastSign; if(!j){ return; }
  if(j.error){ box.className='result show bad'; box.innerHTML='<h4>&#9888; '+t('error')+'</h4><div class="acts">'+esc(j.error)+'</div>'; return; }
  let ok=0,sk=0,er=0; const rows=[];
  (j.results||[]).forEach(it=>{
    if(it.status==='ok'){ ok++; rows.push('<div class="bi"><span class="ic ok">&#10003;</span><span class="nm">'+esc(it.outname||it.name)+'</span></div>'); }
    else if(it.status==='skipped'){ sk++; const why=it.reason==='audio'?t('skip_audio'):esc(it.message||''); rows.push('<div class="bi"><span class="ic sk">&#9888;</span><span class="nm">'+esc(it.name)+' &middot; '+why+'</span></div>'); }
    else { er++; rows.push('<div class="bi"><span class="ic er">&#10007;</span><span class="nm">'+esc(it.name)+' &middot; '+esc(it.message||t('unknown'))+'</span></div>'); }
  });
  box.className='result show '+(er?'bad':(sk&&!ok?'info':'good'));
  let h='<h4>'+(er?'&#9888; ':'&#10003; ')+t('sealed')+'</h4>';
  h+='<div class="acts">'+t('summary').replace('%s',ok).replace('%s',sk).replace('%s',er)+'</div>';
  h+='<div class="blist">'+rows.join('')+'</div>';
  h+='<div><span class="k">'+t('folder')+'</span><span class="v">'+esc(j.outdir||'')+'</span></div>';
  h+='<div class="btnrow"><button onclick="openFolder()">'+t('open_folder')+'</button></div>';
  h+='<div class="hint">'+t('saved_hint')+'</div>';
  box.innerHTML=h;
}

// ---------- verify ----------
const dropV=$('#dropV');
dropV.onclick=()=>$('#fileV').click();
['dragover','dragenter'].forEach(e=>dropV.addEventListener(e,ev=>{ev.preventDefault();dropV.classList.add('hot');}));
['dragleave','drop'].forEach(e=>dropV.addEventListener(e,ev=>{ev.preventDefault();dropV.classList.remove('hot');}));
dropV.addEventListener('drop',ev=>{ if(ev.dataTransfer.files[0]){ fileV=ev.dataTransfer.files[0]; $('#dropVtxt').innerHTML='<span class="fn">'+esc(fileV.name)+'</span>'; $('#verifyBtn').disabled=false; } });
$('#fileV').onchange=()=>{ if($('#fileV').files[0]){ fileV=$('#fileV').files[0]; $('#dropVtxt').innerHTML='<span class="fn">'+esc(fileV.name)+'</span>'; $('#verifyBtn').disabled=false; } };
$('#verifyBtn').onclick=async()=>{
  if(!fileV) return;
  const btn=$('#verifyBtn'); btn.disabled=true; const old=btn.textContent; btn.textContent=t('verifying')+' \u2026';
  const fd=new FormData(); fd.append('file',fileV);
  try{ const r=await fetch('/verify',{method:'POST',body:fd}); lastVerify=await r.json(); }
  catch(e){ lastVerify={status:'error',message:e.message}; }
  renderVerify(); btn.textContent=t('btn_verify'); btn.disabled=false;
};
function aiLabel(key){ return key==='vollstaendig'?t('ai_full'):key==='teilweise'?t('ai_partial'):key==='keine'?t('ai_none'):'\u2013'; }
function row(k,v){return '<div><span class="k">'+k+'</span><span class="v">'+esc(v||'')+'</span></div>';}
function renderVerify(){
  const box=$('#resV'); const j=lastVerify; if(!j) return;
  if(j.status==='ok'){
    const bad=j.real_error; box.className='result show '+(bad?'bad':'good');
    let h=bad?'<h4>&#9888; '+t('failed')+'</h4>':'<h4>&#10003; '+t('valid')+'</h4>';
    h+=row(t('title'),j.title); h+=row(t('author'),j.author||'\u2013');
    h+=row(t('software'),j.software||'\u2013'); h+=row(t('ai'),aiLabel(j.ai));
    if(j.actions&&j.actions.length) h+='<div><span class="k">'+t('actions_label')+'</span><span class="acts">'+j.actions.map(esc).join('<br><span class="k"></span>')+'</span></div>';
    h+=row(t('issuer'),j.issuer||'\u2013'); if(j.time) h+=row(t('signed_on'),j.time);
    if(bad) h+='<div class="acts" style="margin-top:8px;color:#e6a">'+j.validation.map(esc).join(', ')+'</div>';
    h+='<div class="hint">'+t('trust_hint')+'</div>'; box.innerHTML=h;
  } else if(j.status==='none'){
    box.className='result show info'; box.innerHTML='<h4>'+t('no_creds')+'</h4><div class="acts">'+t('no_creds_text')+'</div>';
  } else { box.className='result show bad'; box.innerHTML='<h4>&#9888; '+t('error')+'</h4><div class="acts">'+esc(j.message||t('unknown'))+'</div>'; }
}

async function openFolder(){ try{await fetch('/openfolder');}catch(e){} }
$('#power').onclick=async()=>{
  if(!confirm(t('confirm_quit'))) return;
  try{ await fetch('/quit'); }catch(e){}
  $('#overlay').classList.add('show'); $('#overlay').textContent=t('overlay_quit');
};

// ---------- guide ----------
function loadGuide(){ fetch('/guide?lang='+LANG).then(r=>r.text()).then(t=>{$('#pane-guide').innerHTML=t;}); }

applyLang();
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------
# Guide (DE/EN), served by /guide?lang=
# ---------------------------------------------------------------------
def _schema(lang):
    if lang == "en":
        L = dict(sign="SIGN", verify="VERIFY", guide="GUIDE",
                 drop="Drop files / folder", seal="APPLY SEAL",
                 out="Output: Documents\\C2PA-signed")
    else:
        L = dict(sign="SIGNIEREN", verify="PR\u00dcFEN", guide="ANLEITUNG",
                 drop="Dateien / Ordner ablegen", seal="SIEGEL ANBRINGEN",
                 out="Speicherort: Dokumente\\C2PA-signed")
    return ('<svg class="schema" viewBox="0 0 620 250" xmlns="http://www.w3.org/2000/svg">'
      '<rect x="40" y="14" width="540" height="210" rx="10" fill="#0c0c0c" stroke="#2a2a2a"/>'
      '<rect x="40" y="14" width="540" height="40" rx="10" fill="#161616"/>'
      '<rect x="52" y="24" width="22" height="22" rx="5" fill="#000" stroke="#333"/>'
      '<text x="63" y="39" text-anchor="middle" font-size="10" fill="#fff" font-family="monospace">TN</text>'
      '<text x="86" y="32" font-size="11" fill="#fff" font-family="monospace">TekNerds</text>'
      '<text x="86" y="45" font-size="8" fill="#999" font-family="monospace">C2PA &#183; ' + VERSION + '</text>'
      '<rect x="476" y="26" width="46" height="18" rx="4" fill="#161616" stroke="#333"/>'
      '<text x="499" y="39" text-anchor="middle" font-size="9" fill="#9a9a9a" font-family="monospace">DE | EN</text>'
      '<circle cx="556" cy="34" r="8" fill="#161616" stroke="#333"/>'
      '<text x="556" y="38" text-anchor="middle" font-size="9" fill="#bbb">&#9211;</text>'
      '<rect x="40" y="54" width="90" height="6" fill="#C8C800"/><rect x="130" y="54" width="90" height="6" fill="#17B8C9"/>'
      '<rect x="220" y="54" width="90" height="6" fill="#1FAF3A"/><rect x="310" y="54" width="90" height="6" fill="#C21FC2"/>'
      '<rect x="400" y="54" width="90" height="6" fill="#C8161D"/><rect x="490" y="54" width="90" height="6" fill="#1E2FC4"/>'
      '<text x="100" y="78" text-anchor="middle" font-size="9" fill="#17B8C9" font-family="monospace">' + L["sign"] + '</text>'
      '<text x="230" y="78" text-anchor="middle" font-size="9" fill="#888" font-family="monospace">' + L["verify"] + '</text>'
      '<text x="360" y="78" text-anchor="middle" font-size="9" fill="#888" font-family="monospace">' + L["guide"] + '</text>'
      '<rect x="60" y="92" width="500" height="50" rx="8" fill="#0e0e0e" stroke="#3a3a3a" stroke-dasharray="4 3"/>'
      '<text x="310" y="121" text-anchor="middle" font-size="11" fill="#aaa" font-family="monospace">' + L["drop"] + '</text>'
      '<rect x="60" y="150" width="500" height="14" rx="3" fill="#101010" stroke="#262626"/>'
      '<text x="66" y="161" font-size="8" fill="#888" font-family="monospace">file_01 ... file_n</text>'
      '<rect x="60" y="172" width="500" height="30" rx="7" fill="#0f6f7d"/>'
      '<text x="310" y="191" text-anchor="middle" font-size="11" fill="#fff" font-family="monospace" letter-spacing="2">' + L["seal"] + '</text>'
      '<text x="60" y="218" font-size="9" fill="#888" font-family="monospace">' + L["out"] + '</text>'
      '</svg>')

def guide_html(lang):
    if lang == "en":
        return ("<h3>What the tool looks like</h3>" + _schema("en") +
        "<p>Top left the TN logo, top centre the <b>DE | EN</b> language switch, "
        "top right the power button (&#9211;). Below it the tabs <b>Sign / Verify / Guide</b>. "
        "In the Sign tab you can add <b>several files or a whole folder</b> at once.</p>"
        "<h3>What you need</h3><ul>"
        "<li>Windows 10/11</li>"
        "<li><b>c2patool.exe</b> &#8211; downloaded automatically on first start if missing.</li>"
        "<li>Python (only for the script version; the EXE needs none).</li></ul>"
        "<h3>1 &middot; Install</h3><ul>"
        "<li>Put the folder somewhere fixed, start <code>Start_C2PA_Tool.bat</code> or the EXE.</li>"
        "<li>First start: Windows SmartScreen &rarr; &bdquo;More info&ldquo; &rarr; &bdquo;Run anyway&ldquo;.</li></ul>"
        "<h3>2 &middot; Sign (batch)</h3><ul>"
        "<li>Drop <b>files or a folder</b>, or use &bdquo;Choose files&ldquo; / &bdquo;Choose folder&ldquo;.</li>"
        "<li>Fill in author, software, action, AI use &#8211; these apply to <b>all</b> files in the batch.</li>"
        "<li><b>Apply seal</b> &rarr; every file is signed and saved to <code>Documents\\C2PA-signed</code> "
        "(folder structure is preserved). Unsupported audio is skipped with a note.</li></ul>"
        "<h3>3 &middot; Verify</h3><ul><li>Drop a file in the <b>Verify</b> tab &rarr; shows author, "
        "software, AI status, edit history and issuer.</li></ul>"
        "<h3>Good to know</h3><ul>"
        "<li><b>.mov</b> only partially supported &rarr; use <b>MP4</b>.</li>"
        "<li><b>Audio</b>: only <b>WAV, MP3, M4A</b> can embed C2PA.</li>"
        "<li>Test certificate &rarr; &bdquo;issuer not on the trust list&ldquo; is normal.</li>"
        "<li><b>Created</b> = original &middot; <b>Edited</b> = changed from existing material.</li>"
        "<li><b>assertion.dataHash.mismatch</b> = file changed after signing (a real error).</li>"
        "<li>Stop the server: power button (&#9211;).</li></ul>"
        "<h3>If something goes wrong</h3><ul>"
        "<li>Browser does not open: open <code>http://127.0.0.1:8731</code>.</li>"
        "<li>&bdquo;c2patool not found&ldquo;: place <code>c2patool.exe</code> next to the app or run Setup.</li>"
        "<li>Old view / port in use: power button, or <code>Ctrl+Shift+R</code> in the browser.</li></ul>"
        "<h3>Licenses &amp; rights</h3>"
        "<p><b>c2patool</b> (c2pa-rs) is &copy; <b>Adobe</b>, dual licensed <b>Apache-2.0</b> OR <b>MIT</b> "
        "(github.com/contentauth/c2pa-rs), bundled unchanged. Full texts in the <b>&bdquo;Licenses&ldquo;</b> folder.</p>"
        "<p style='color:#7d7d7d'>GUI idea: TekNerds &middot; Nils Voss &amp; Christian Homburg. "
        "Base framework created with Claude (Anthropic).</p>")
    # German
    return ("<h3>So sieht das Tool aus</h3>" + _schema("de") +
    "<p>Oben links das TN-Logo, in der Mitte der Sprachschalter <b>DE | EN</b>, "
    "rechts der Power-Knopf (&#9211;). Darunter die Reiter <b>Signieren / Pr\u00fcfen / Anleitung</b>. "
    "Im Reiter Signieren kannst du <b>mehrere Dateien oder einen ganzen Ordner</b> auf einmal hinzuf\u00fcgen.</p>"
    "<h3>Was du brauchst</h3><ul>"
    "<li>Windows 10/11</li>"
    "<li><b>c2patool.exe</b> &#8211; wird beim ersten Start automatisch geladen, falls es fehlt.</li>"
    "<li>Python (nur f\u00fcr die Skript-Variante; die EXE braucht keins).</li></ul>"
    "<h3>1 &middot; Installieren</h3><ul>"
    "<li>Ordner an einen festen Platz legen, <code>Start_C2PA_Tool.bat</code> oder die EXE starten.</li>"
    "<li>Erster Start: Windows SmartScreen &rarr; &bdquo;Weitere Informationen&ldquo; &rarr; &bdquo;Trotzdem ausf\u00fchren&ldquo;.</li></ul>"
    "<h3>2 &middot; Signieren (Stapel)</h3><ul>"
    "<li><b>Dateien oder einen Ordner</b> ablegen, oder &bdquo;Dateien w\u00e4hlen&ldquo; / &bdquo;Ordner w\u00e4hlen&ldquo;.</li>"
    "<li>Urheber, Software, Aktion, KI-Einsatz ausf\u00fcllen &#8211; gilt f\u00fcr <b>alle</b> Dateien im Stapel.</li>"
    "<li><b>Siegel anbringen</b> &rarr; jede Datei wird signiert und in <code>Dokumente\\C2PA-signed</code> "
    "gespeichert (Ordnerstruktur bleibt erhalten). Nicht einbettbares Audio wird mit Hinweis \u00fcbersprungen.</li></ul>"
    "<h3>3 &middot; Pr\u00fcfen</h3><ul><li>Im Reiter <b>Pr\u00fcfen</b> eine Datei ablegen &rarr; zeigt Urheber, "
    "Software, KI-Status, Bearbeitungsverlauf und Aussteller.</li></ul>"
    "<h3>Gut zu wissen</h3><ul>"
    "<li><b>.mov</b> nur eingeschr\u00e4nkt unterst\u00fctzt &rarr; <b>MP4</b> nehmen.</li>"
    "<li><b>Audio</b>: nur <b>WAV, MP3, M4A</b> k\u00f6nnen C2PA einbetten.</li>"
    "<li>Test-Zertifikat &rarr; &bdquo;Aussteller nicht auf der Vertrauensliste&ldquo; ist normal.</li>"
    "<li><b>Erstellt</b> = Original &middot; <b>Bearbeitet</b> = aus vorhandenem Material ver\u00e4ndert.</li>"
    "<li><b>assertion.dataHash.mismatch</b> = Datei nach Signatur ver\u00e4ndert (echter Fehler).</li>"
    "<li>Server beenden: Power-Knopf (&#9211;).</li></ul>"
    "<h3>Wenn etwas klemmt</h3><ul>"
    "<li>Browser \u00f6ffnet nicht: <code>http://127.0.0.1:8731</code> aufrufen.</li>"
    "<li>&bdquo;c2patool nicht gefunden&ldquo;: <code>c2patool.exe</code> neben die App legen oder Setup ausf\u00fchren.</li>"
    "<li>Alte Ansicht / Port belegt: Power-Knopf, oder <code>Strg+Umschalt+R</code> im Browser.</li></ul>"
    "<h3>Lizenzen &amp; Rechte</h3>"
    "<p><b>c2patool</b> (c2pa-rs) ist &copy; <b>Adobe</b>, doppelt lizenziert <b>Apache-2.0</b> ODER <b>MIT</b> "
    "(github.com/contentauth/c2pa-rs), wird unver\u00e4ndert mitgeliefert. Vollst\u00e4ndige Texte im Ordner <b>&bdquo;Licenses&ldquo;</b>.</p>"
    "<p style='color:#7d7d7d'>GUI-Idee: TekNerds &middot; Nils Voss &amp; Christian Homburg. "
    "Grundger\u00fcst erstellt mit Claude (Anthropic).</p>")


# ---------------------------------------------------------------------
# HTTP handler
# ---------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "TekNerdsC2PA/2.0"
    def log_message(self, *a): pass

    def _send(self, code, body, ctype="text/html; charset=utf-8"):
        if isinstance(body, str): body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try: self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError): pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False),
                   "application/json; charset=utf-8")

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        # robustes Lesen grosser Uploads
        buf = bytearray(); remaining = length
        while remaining > 0:
            chunk = self.rfile.read(min(remaining, 1 << 20))
            if not chunk: break
            buf.extend(chunk); remaining -= len(chunk)
        return bytes(buf)

    def do_GET(self):
        from urllib.parse import urlparse, parse_qs
        parsed = urlparse(self.path); path = parsed.path
        if path == "/":
            self._send(200, page_html())
        elif path == "/guide":
            lang = (parse_qs(parsed.query).get("lang") or ["de"])[0]
            self._send(200, guide_html("en" if lang == "en" else "de"))
        elif path == "/openfolder":
            try:
                os.makedirs(OUTPUT_DIR, exist_ok=True)
                if os.name == "nt": os.startfile(OUTPUT_DIR)  # noqa
                elif sys.platform == "darwin": subprocess.Popen(["open", OUTPUT_DIR])
                else: subprocess.Popen(["xdg-open", OUTPUT_DIR])
            except Exception: pass
            self._json({"ok": True})
        elif path == "/download":
            self._handle_download(parsed)
        elif path == "/quit":
            self._json({"ok": True})
            threading.Thread(target=_shutdown, daemon=True).start()
        else:
            self._send(404, "not found")

    def _handle_download(self, parsed):
        from urllib.parse import parse_qs
        rel = (parse_qs(parsed.query).get("name") or [""])[0]
        fp = os.path.normpath(os.path.join(OUTPUT_DIR, safe_relpath(rel)))
        if not rel or not fp.startswith(os.path.normpath(OUTPUT_DIR)) or not os.path.isfile(fp):
            self._send(404, "not found"); return
        with open(fp, "rb") as f: data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Disposition",
                         'attachment; filename="%s"' % os.path.basename(fp))
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        try: self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError): pass

    def do_POST(self):
        path = self.path.split("?", 1)[0]
        ctype = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in ctype:
            self._json({"error": "expected multipart"}, 400); return
        m = re.search(r"boundary=([^;]+)", ctype)
        if not m:
            self._json({"error": "boundary missing"}, 400); return
        boundary = m.group(1).strip().strip('"').encode("utf-8")
        fields, files = parse_multipart(self._read_body(), boundary)
        if not files:
            self._json({"error": "no file received"}, 400); return
        if path == "/sign":
            self._do_sign(fields, files)
        elif path == "/verify":
            self._do_verify(files[0])
        else:
            self._send(404, "not found")

    def _do_sign(self, fields, files):
        # relative Pfade (Ordner-Upload) ausrichten
        try:
            paths = json.loads(fields.get("paths") or "[]")
        except json.JSONDecodeError:
            paths = []
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        results = []
        tmpdir = tempfile.mkdtemp(prefix="c2pa_batch_")
        try:
            for i, (_name, filename, content) in enumerate(files):
                rel = paths[i] if i < len(paths) else filename
                rel = safe_relpath(rel) or safe_name(filename)
                base = os.path.basename(rel)
                subdir = os.path.dirname(rel)
                disp = rel.replace("\\", "/")
                e = ext_of(base)
                if e in AUDIO_BAD:
                    results.append({"name": disp, "status": "skipped", "reason": "audio"})
                    continue
                src = os.path.join(tmpdir, base)
                with open(src, "wb") as f:
                    f.write(content)
                out_sub = os.path.join(OUTPUT_DIR, subdir) if subdir else OUTPUT_DIR
                os.makedirs(out_sub, exist_ok=True)
                stem, ext2 = os.path.splitext(base)
                outname = stem + "_c2pa" + ext2
                outpath = os.path.join(out_sub, outname)
                ok, msg = sign_file(src, outpath, fields)
                rel_out = os.path.join(subdir, outname).replace("\\", "/") if subdir else outname
                if ok:
                    results.append({"name": disp, "status": "ok", "outname": rel_out})
                else:
                    if msg == "no-c2patool":
                        msg = "c2patool not found"
                    elif msg == "timeout":
                        msg = "timeout"
                    results.append({"name": disp, "status": "failed", "message": msg})
                try: os.remove(src)
                except OSError: pass
            self._json({"results": results, "outdir": OUTPUT_DIR})
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _do_verify(self, file_tuple):
        _name, filename, content = file_tuple
        tmpdir = tempfile.mkdtemp(prefix="c2pa_vf_")
        src = os.path.join(tmpdir, safe_name(filename))
        try:
            with open(src, "wb") as f: f.write(content)
            self._json(verify_file(src))
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)


# ---------------------------------------------------------------------
# server
# ---------------------------------------------------------------------
_httpd = None
def _shutdown():
    global _httpd
    time.sleep(0.4)
    try:
        if _httpd: _httpd.shutdown()
    except Exception: pass
    os._exit(0)

def _port_free(host, port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((host, port)); return True
    except OSError:
        return False
    finally:
        s.close()

def main():
    global _httpd, PORT, C2PATOOL
    if not C2PATOOL:
        print("c2patool not found - downloading it once ...")
        C2PATOOL = autofetch_c2patool() or find_c2patool()
        print("   " + ("OK: " + C2PATOOL if C2PATOOL else
                        "could not download - place c2patool.exe next to the app."))
    port = PORT
    for _ in range(20):
        if _port_free(HOST, port): break
        port += 1
    PORT = port
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    _httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    url = "http://%s:%d" % (HOST, PORT)
    print("=" * 56)
    print(" %s  %s" % (APP_NAME, VERSION))
    print(" running at:        %s" % url)
    print(" signed files:      %s" % OUTPUT_DIR)
    print(" c2patool:          %s" % (C2PATOOL or "NOT FOUND"))
    print(" quit:              power button or Ctrl+C")
    print("=" * 56)
    if "--no-browser" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        _httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped."); os._exit(0)

if __name__ == "__main__":
    main()
