@echo off
chcp 65001 >nul
title TekNerds C2PA - Setup
cd /d "%~dp0"
echo ================================================================
echo   TekNerds C2PA  -  Setup (Windows)
echo   Laedt c2patool.exe / downloads c2patool.exe
echo ================================================================
echo.
if exist "c2patool.exe" (
  echo c2patool.exe bereits vorhanden / already present.
  echo.
  pause
  goto :eof
)
set "VER=v0.26.67"
set "ZIP=c2patool-%VER%-x86_64-pc-windows-msvc.zip"
set "URL=https://github.com/contentauth/c2pa-rs/releases/download/c2patool-%VER%/%ZIP%"
echo [1/3] Download c2patool %VER% ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "try { Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP%' -UseBasicParsing; Write-Host '   OK' }" ^
  "catch { Write-Host '   suche neueste / searching latest ...';" ^
  "  $rels = Invoke-RestMethod -Uri 'https://api.github.com/repos/contentauth/c2pa-rs/releases?per_page=60' -Headers @{ 'User-Agent'='TekNerds' };" ^
  "  $asset = $rels | Where-Object { $_.tag_name -like 'c2patool-*' } | ForEach-Object { $_.assets } | Where-Object { $_.name -like '*x86_64-pc-windows-msvc.zip' } | Select-Object -First 1;" ^
  "  if (-not $asset) { Write-Host '   FEHLER/ERROR: kein Windows-Asset / no windows asset'; exit 1 }" ^
  "  Invoke-WebRequest -Uri $asset.browser_download_url -OutFile '%ZIP%' -UseBasicParsing }"
if not exist "%ZIP%" (
  echo FEHLER/ERROR: Download. Manuell / manually:
  echo   https://github.com/contentauth/c2pa-rs/releases  (Filter: c2patool)
  echo.
  pause
  goto :eof
)
echo [2/3] Entpacken / extracting ...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP%' -DestinationPath '_c2pa_tmp' -Force"
echo [3/3] c2patool.exe bereitstellen / placing ...
for /r "_c2pa_tmp" %%F in (c2patool.exe) do copy /Y "%%F" "c2patool.exe" >nul
rmdir /S /Q "_c2pa_tmp" 2>nul
del /Q "%ZIP%" 2>nul
if exist "c2patool.exe" ( echo FERTIG / DONE. ) else ( echo FEHLER/ERROR beim Entpacken / extracting. )
echo.
pause
